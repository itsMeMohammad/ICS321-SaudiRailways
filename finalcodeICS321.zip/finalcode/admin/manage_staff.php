<?php
session_start();
require_once '../includes/db_connection.php';

// Check if user is logged in as admin
if (!isset($_SESSION['staff_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../staff_login.php");
    exit();
}

// Handle Actions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'assign':
                assignStaffToTrain();
                break;
            case 'remove':
                removeStaffFromTrain();
                break;
            case 'add':
                addNewStaffMember();
                break;
        }
    }
}

// Function to assign staff to train
function assignStaffToTrain() {
    global $conn;
    try {
        $staff_id = $_POST['staff_id'];
        $train_id = $_POST['train_id'];
        $date = $_POST['assignment_date'];
        $role = $_POST['role'];

        // Check if staff is already assigned to a train on that date
        $stmt = $conn->prepare("SELECT * FROM staff_assignments WHERE Staff_ID = ? AND Assignment_Date = ?");
        $stmt->bind_param("is", $staff_id, $date);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            throw new Exception("Staff member is already assigned to a train on this date.");
        }

        // Insert new assignment
        $stmt = $conn->prepare("INSERT INTO staff_assignments (Staff_ID, Train_ID, Assignment_Date, Role) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("iiss", $staff_id, $train_id, $date, $role);
        $stmt->execute();

        $_SESSION['success_message'] = "Staff member successfully assigned to train.";
    } catch (Exception $e) {
        $_SESSION['error_message'] = "Error assigning staff: " . $e->getMessage();
    }
}

// Function to remove staff from train
function removeStaffFromTrain() {
    global $conn;
    try {
        $assignment_id = $_POST['assignment_id'];
        
        $stmt = $conn->prepare("DELETE FROM staff_assignments WHERE Assignment_ID = ?");
        $stmt->bind_param("i", $assignment_id);
        $stmt->execute();

        $_SESSION['success_message'] = "Staff assignment removed successfully.";
    } catch (Exception $e) {
        $_SESSION['error_message'] = "Error removing assignment: " . $e->getMessage();
    }
}

// Function to add new staff member
function addNewStaffMember() {
    global $conn;
    try {
        $conn->begin_transaction();

        // Insert into person table
        $fname = $_POST['fname'];
        $lname = $_POST['lname'];
        $email = $_POST['email'];
        $phone = $_POST['phone'];

        // Generate a new Person_ID
        $stmt = $conn->prepare("SELECT MAX(Person_ID) as max_id FROM person");
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        $new_person_id = $row['max_id'] + 1;

        // Insert person
        $stmt = $conn->prepare("INSERT INTO person (Person_ID, FName, LName) VALUES (?, ?, ?)");
        $stmt->bind_param("iss", $new_person_id, $fname, $lname);
        $stmt->execute();

        // Insert contact info
        $stmt = $conn->prepare("INSERT INTO person_contact_info (Phone, Person_ID, Email) VALUES (?, ?, ?)");
        $stmt->bind_param("sis", $phone, $new_person_id, $email);
        $stmt->execute();

        // Insert staff member
        $role = $_POST['staff_role'];
        $stmt = $conn->prepare("INSERT INTO staff_member (Person_ID, Role) VALUES (?, ?)");
        $stmt->bind_param("is", $new_person_id, $role);
        $stmt->execute();

        // Create staff user account
        $username = strtolower($fname . "." . $lname);
        $password = '123'; // Default password
        $stmt = $conn->prepare("INSERT INTO staff_users (username, password, Person_ID, role) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssis", $username, $password, $new_person_id, $role);
        $stmt->execute();

        $conn->commit();
        $_SESSION['success_message'] = "New staff member added successfully. Username: $username";
    } catch (Exception $e) {
        $conn->rollback();
        $_SESSION['error_message'] = "Error adding staff member: " . $e->getMessage();
    }
}

// Get all staff members
$staff_query = "SELECT sm.Person_ID, p.FName, p.LName, sm.Role 
                FROM staff_member sm 
                JOIN person p ON sm.Person_ID = p.Person_ID";
$staff_result = $conn->query($staff_query);

// Get all trains
$trains_query = "SELECT Train_ID, English_Name FROM train";
$trains_result = $conn->query($trains_query);

// Get current assignments
$assignments_query = "SELECT sa.Assignment_ID, sa.Assignment_Date, 
                            p.FName, p.LName, sm.Role,
                            t.English_Name as train_name
                     FROM staff_assignments sa
                     JOIN staff_member sm ON sa.Staff_ID = sm.Person_ID
                     JOIN person p ON sm.Person_ID = p.Person_ID
                     JOIN train t ON sa.Train_ID = t.Train_ID
                     ORDER BY sa.Assignment_Date DESC";
$assignments_result = $conn->query($assignments_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Staff - Admin Panel</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f4f4f4;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background-color: white;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .section {
            margin-bottom: 30px;
            padding: 20px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: left;
        }
        th {
            background-color: #007bff;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        .btn {
            padding: 8px 15px;
            border: none;
            border-radius: 3px;
            cursor: pointer;
            color: white;
            text-decoration: none;
            display: inline-block;
            margin: 2px;
        }
        .btn-primary { background-color: #007bff; }
        .btn-success { background-color: #28a745; }
        .btn-danger { background-color: #dc3545; }
        .message {
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 3px;
        }
        .success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
        }
        .modal-content {
            background-color: white;
            margin: 15% auto;
            padding: 20px;
            border-radius: 5px;
            width: 50%;
        }
        .close {
            float: right;
            cursor: pointer;
            font-size: 24px;
        }
        form {
            display: grid;
            gap: 10px;
        }
        input, select {
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 3px;
            width: 100%;
        }
    </style>
</head>
<body>
<div class="nav-bar" style="margin-bottom: 20px; padding: 10px; background-color: #333;">
        <a href="index.php" style="color: white; text-decoration: none; margin-right: 20px;">Dashboard</a>
        <a href="manage_reservations.php" style="color: white; text-decoration: none; margin-right: 20px;">Reservations</a>
        <a href="manage_staff.php" style="color: white; text-decoration: none; margin-right: 20px;">Staff</a>
        <a href="manage_waitlist.php" style="color: white; text-decoration: none; margin-right: 20px;">Waitlist</a>
        <a href="../logout.php" style="color: white; text-decoration: none; float: right;">Logout</a>
    </div>
    <div class="container">
        <h1>Manage Staff</h1>

        <?php if (isset($_SESSION['success_message'])): ?>
            <div class="message success">
                <?php 
                echo $_SESSION['success_message'];
                unset($_SESSION['success_message']);
                ?>
            </div>
        <?php endif; ?>

        <?php if (isset($_SESSION['error_message'])): ?>
            <div class="message error">
                <?php 
                echo $_SESSION['error_message'];
                unset($_SESSION['error_message']);
                ?>
            </div>
        <?php endif; ?>

        <!-- Staff Assignment Section -->
        <div class="section">
            <h2>Assign Staff to Train</h2>
            <button class="btn btn-primary" onclick="showAssignModal()">New Assignment</button>
            
            <table>
                <thead>
                    <tr>
                        <th>Staff Name</th>
                        <th>Role</th>
                        <th>Train</th>
                        <th>Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($assignment = $assignments_result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $assignment['FName'] . ' ' . $assignment['LName']; ?></td>
                        <td><?php echo $assignment['Role']; ?></td>
                        <td><?php echo $assignment['train_name']; ?></td>
                        <td><?php echo $assignment['Assignment_Date']; ?></td>
                        <td>
                            <button class="btn btn-danger" onclick="confirmRemove(<?php echo $assignment['Assignment_ID']; ?>)">Remove</button>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>

        <!-- Staff Management Section -->
        <div class="section">
            <h2>Staff Members</h2>
            <button class="btn btn-primary" onclick="showAddStaffModal()">Add New Staff</button>
            
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Role</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($staff = $staff_result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $staff['Person_ID']; ?></td>
                        <td><?php echo $staff['FName'] . ' ' . $staff['LName']; ?></td>
                        <td><?php echo $staff['Role']; ?></td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Assign Staff Modal -->
    <div id="assignModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal('assignModal')">&times;</span>
            <h2>Assign Staff to Train</h2>
            <form method="POST">
                <input type="hidden" name="action" value="assign">
                
                <label for="staff_id">Staff Member:</label>
                <select name="staff_id" required>
                    <?php 
                    $staff_result->data_seek(0);
                    while($staff = $staff_result->fetch_assoc()): 
                    ?>
                        <option value="<?php echo $staff['Person_ID']; ?>">
                            <?php echo $staff['FName'] . ' ' . $staff['LName'] . ' (' . $staff['Role'] . ')'; ?>
                        </option>
                    <?php endwhile; ?>
                </select>

                <label for="train_id">Train:</label>
                <select name="train_id" required>
                    <?php while($train = $trains_result->fetch_assoc()): ?>
                        <option value="<?php echo $train['Train_ID']; ?>">
                            <?php echo $train['English_Name']; ?>
                        </option>
                    <?php endwhile; ?>
                </select>

                <label for="assignment_date">Date:</label>
                <input type="date" name="assignment_date" required>

                <label for="role">Role:</label>
                <select name="role" required>
                    <option value="Driver">Driver</option>
                    <option value="Engineer">Engineer</option>
                    <option value="Conductor">Conductor</option>
                </select>

                <button type="submit" class="btn btn-primary">Assign Staff</button>
            </form>
        </div>
    </div>

    <!-- Add Staff Modal -->
    <div id="addStaffModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal('addStaffModal')">&times;</span>
            <h2>Add New Staff Member</h2>
            <form method="POST">
                <input type="hidden" name="action" value="add">
                
                <label for="fname">First Name:</label>
                <input type="text" name="fname" required>

                <label for="lname">Last Name:</label>
                <input type="text" name="lname" required>

                <label for="email">Email:</label>
                <input type="email" name="email" required>

                <label for="phone">Phone:</label>
                <input type="text" name="phone" required>

                <label for="staff_role">Role:</label>
                <select name="staff_role" required>
                    <option value="Driver">Driver</option>
                    <option value="Engineer">Engineer</option>
                    <option value="Conductor">Conductor</option>
                    <option value="Station Manager">Station Manager</option>
                </select>

                <button type="submit" class="btn btn-primary">Add Staff Member</button>
            </form>
        </div>
    </div>

    <script>
        function showAssignModal() {
            document.getElementById('assignModal').style.display = 'block';
        }

        function showAddStaffModal() {
            document.getElementById('addStaffModal').style.display = 'block';
        }

        function closeModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
        }

        function confirmRemove(assignmentId) {
            if (confirm('Are you sure you want to remove this assignment?')) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.innerHTML = `
                    <input type="hidden" name="action" value="remove">
                    <input type="hidden" name="assignment_id" value="${assignmentId}">
                `;
                document.body.appendChild(form);
                form.submit();
            }
        }

        // Close modal when clicking outside
        window.onclick = function(event) {
            if (event.target.className === 'modal') {
                event.target.style.display = 'none';
            }
        }
    </script>
</body>
</html>