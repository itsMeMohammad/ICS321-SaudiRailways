<?php
session_start();
require_once '../includes/db_connection.php';

// Check if user is logged in as admin
if (!isset($_SESSION['staff_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../staff_login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f4f4f4;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background-color: white;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .dashboard-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }
        .dashboard-item {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            text-align: center;
        }
        .btn {
            display: inline-block;
            padding: 15px 25px;
            background-color: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s;
            width: 100%;
            box-sizing: border-box;
            margin-top: 10px;
        }
        .btn:hover {
            background-color: #0056b3;
        }
        h1 {
            color: #333;
            text-align: center;
        }
        .icon {
            font-size: 48px;
            margin-bottom: 10px;
        }
        .logout-btn {
            background-color: #dc3545;
            float: right;
        }
    </style>
</head>
<body>
    <div class="container">
        <a href="../logout.php" class="btn logout-btn">Logout</a>
        <h1>Admin Dashboard</h1>
        
        <div class="dashboard-grid">
            <div class="dashboard-item">
                <div class="icon">🎫</div>
                <h2>Manage Reservations</h2>
                <p>Add, edit, or cancel passenger reservations</p>
                <a href="manage_reservations.php" class="btn">Go to Reservations</a>
            </div>

            <div class="dashboard-item">
                <div class="icon">👥</div>
                <h2>Manage Staff</h2>
                <p>Assign staff to trains and manage staff members</p>
                <a href="manage_staff.php" class="btn">Go to Staff Management</a>
            </div>

            <div class="dashboard-item">
                <div class="icon">⏳</div>
                <h2>Manage Waitlist</h2>
                <p>Handle waitlisted passengers and promotions</p>
                <a href="manage_waitlist.php" class="btn">Go to Waitlist</a>
            </div>
        </div>
    </div>
</body>
</html>