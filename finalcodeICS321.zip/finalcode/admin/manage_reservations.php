<?php
session_start();
require_once '../includes/db_connection.php';

// Check if user is logged in as admin
if (!isset($_SESSION['staff_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../staff_login.php");
    exit();
}

// Handle Actions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'cancel':
                if (isset($_POST['reservation_id'])) {
                    cancelReservation($_POST['reservation_id']);
                }
                break;
            case 'edit':
                if (isset($_POST['reservation_id'])) {
                    updateReservation($_POST['reservation_id']);
                }
                break;
            case 'add':
                addNewReservation();
                break;
        }
    }
}

// Function to cancel reservation
function cancelReservation($reservation_id) {
    global $conn;
    try {
        // Start transaction
        $conn->begin_transaction();

        // Update reservation status
        $stmt = $conn->prepare("UPDATE reservation SET Reservation_Status = 'Cancelled', Payment_Status = 'Cancelled' WHERE Reservation_ID = ?");
        $stmt->bind_param("i", $reservation_id);
        $stmt->execute();

        // Update payment status
        $stmt = $conn->prepare("UPDATE payment SET Status = 'Cancelled' WHERE Reservation_ID = ?");
        $stmt->bind_param("i", $reservation_id);
        $stmt->execute();

        // Commit transaction
        $conn->commit();
        $_SESSION['success_message'] = "Reservation cancelled successfully.";
    } catch (Exception $e) {
        $conn->rollback();
        $_SESSION['error_message'] = "Error cancelling reservation: " . $e->getMessage();
    }
}

// Function to update reservation
function updateReservation($reservation_id) {
    global $conn;
    try {
        $seat_number = $_POST['seat_number'];
        $coach_class = $_POST['coach_class'];
        $luggage_details = $_POST['luggage_details'];
        
        $stmt = $conn->prepare("UPDATE reservation SET 
            Seat_Number = ?,
            Coach_Class = ?,
            Luggage_Details = ?
            WHERE Reservation_ID = ?");
        
        $stmt->bind_param("issi", $seat_number, $coach_class, $luggage_details, $reservation_id);
        $stmt->execute();
        
        $_SESSION['success_message'] = "Reservation updated successfully.";
    } catch (Exception $e) {
        $_SESSION['error_message'] = "Error updating reservation: " . $e->getMessage();
    }
}

// Function to add new reservation
function addNewReservation() {
    global $conn;
    try {
        $passenger_id = $_POST['passenger_id'];
        $train_id = $_POST['train_id'];
        $seat_number = $_POST['seat_number'];
        $from_station = $_POST['from_station'];
        $to_station = $_POST['to_station'];
        $coach_class = $_POST['coach_class'];
        $luggage_details = $_POST['luggage_details'];
        $price = $_POST['price'];
        
        // Get passenger name from person table
        $stmt = $conn->prepare("SELECT CONCAT(FName, ' ', LName) as full_name FROM person WHERE Person_ID = ?");
        $stmt->bind_param("i", $passenger_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $passenger = $result->fetch_assoc();
        $name = $passenger['full_name'];

        $stmt = $conn->prepare("INSERT INTO reservation 
            (Seat_Number, Passenger_ID, Train_ID, From_Station, To_Station, 
            Coach_Class, Payment_Status, Reservation_Status, Luggage_Details, 
            Person_ID, Name, Price) 
            VALUES (?, ?, ?, ?, ?, ?, 'Pending', 'Confirmed', ?, ?, ?, ?)");
        
        $stmt->bind_param("iiisssssd", $seat_number, $passenger_id, $train_id, 
            $from_station, $to_station, $coach_class, $luggage_details, 
            $passenger_id, $name, $price);
        
        $stmt->execute();
        $_SESSION['success_message'] = "New reservation added successfully.";
    } catch (Exception $e) {
        $_SESSION['error_message'] = "Error adding reservation: " . $e->getMessage();
    }
}

// Get all reservations
$query = "SELECT r.*, p.FName, p.LName, t.English_Name as train_name 
          FROM reservation r 
          JOIN person p ON r.Person_ID = p.Person_ID 
          JOIN train t ON r.Train_ID = t.Train_ID 
          ORDER BY r.Reservation_ID DESC";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Reservations - Admin Panel</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f4f4f4;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background-color: white;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: left;
        }
        th {
            background-color: #007bff;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        .btn {
            padding: 5px 10px;
            border: none;
            border-radius: 3px;
            cursor: pointer;
            color: white;
            text-decoration: none;
            display: inline-block;
            margin: 2px;
        }
        .btn-edit {
            background-color: #28a745;
        }
        .btn-cancel {
            background-color: #dc3545;
        }
        .btn-add {
            background-color: #007bff;
            margin-bottom: 20px;
        }
        .message {
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 3px;
        }
        .success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
        }
        .modal-content {
            background-color: white;
            margin: 15% auto;
            padding: 20px;
            border-radius: 5px;
            width: 50%;
        }
        .close {
            float: right;
            cursor: pointer;
            font-size: 24px;
        }
        form {
            display: grid;
            gap: 10px;
        }
        input, select {
            padding: 5px;
            border: 1px solid #ddd;
            border-radius: 3px;
        }
    </style>
</head>
<body>
    <div class="nav-bar" style="margin-bottom: 20px; padding: 10px; background-color: #333;">
        <a href="index.php" style="color: white; text-decoration: none; margin-right: 20px;">Dashboard</a>
        <a href="manage_reservations.php" style="color: white; text-decoration: none; margin-right: 20px;">Reservations</a>
        <a href="manage_staff.php" style="color: white; text-decoration: none; margin-right: 20px;">Staff</a>
        <a href="manage_waitlist.php" style="color: white; text-decoration: none; margin-right: 20px;">Waitlist</a>
        <a href="../logout.php" style="color: white; text-decoration: none; float: right;">Logout</a>
    </div>
    <div class="container">
        <h1>Manage Reservations</h1>
        
        <?php if (isset($_SESSION['success_message'])): ?>
            <div class="message success">
                <?php 
                echo $_SESSION['success_message'];
                unset($_SESSION['success_message']);
                ?>
            </div>
        <?php endif; ?>

        <?php if (isset($_SESSION['error_message'])): ?>
            <div class="message error">
                <?php 
                echo $_SESSION['error_message'];
                unset($_SESSION['error_message']);
                ?>
            </div>
        <?php endif; ?>

        <!-- Add New Reservation Button -->
        <button class="btn btn-add" onclick="showAddModal()">Add New Reservation</button>

        <!-- Reservations Table -->
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Passenger Name</th>
                    <th>Train</th>
                    <th>From</th>
                    <th>To</th>
                    <th>Class</th>
                    <th>Status</th>
                    <th>Price</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $row['Reservation_ID']; ?></td>
                    <td><?php echo $row['FName'] . ' ' . $row['LName']; ?></td>
                    <td><?php echo $row['train_name']; ?></td>
                    <td><?php echo $row['From_Station']; ?></td>
                    <td><?php echo $row['To_Station']; ?></td>
                    <td><?php echo $row['Coach_Class']; ?></td>
                    <td><?php echo $row['Reservation_Status']; ?></td>
                    <td><?php echo $row['Price']; ?></td>
                    <td>
                        <button class="btn btn-edit" onclick="showEditModal(<?php echo htmlspecialchars(json_encode($row)); ?>)">Edit</button>
                        <button class="btn btn-cancel" onclick="confirmCancel(<?php echo $row['Reservation_ID']; ?>)">Cancel</button>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>

    <!-- Edit Reservation Modal -->
    <div id="editModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal('editModal')">&times;</span>
            <h2>Edit Reservation</h2>
            <form id="editForm" method="POST">
                <input type="hidden" name="action" value="edit">
                <input type="hidden" name="reservation_id" id="edit_reservation_id">
                
                <label for="seat_number">Seat Number:</label>
                <input type="number" name="seat_number" id="edit_seat_number" required>
                
                <label for="coach_class">Class:</label>
                <select name="coach_class" id="edit_coach_class" required>
                    <option value="Economy Class">Economy Class</option>
                    <option value="Business Class">Business Class</option>
                </select>
                
                <label for="luggage_details">Luggage Details:</label>
                <input type="text" name="luggage_details" id="edit_luggage_details">
                
                <button type="submit" class="btn btn-edit">Update Reservation</button>
            </form>
        </div>
    </div>

    <!-- Add New Reservation Modal -->
    <div id="addModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal('addModal')">&times;</span>
            <h2>Add New Reservation</h2>
            <form method="POST">
                <input type="hidden" name="action" value="add">
                
                <label for="passenger_id">Passenger ID:</label>
                <input type="number" name="passenger_id" required>
                
                <label for="train_id">Train ID:</label>
                <input type="number" name="train_id" required>
                
                <label for="seat_number">Seat Number:</label>
                <input type="number" name="seat_number" required>
                
                <label for="from_station">From Station:</label>
                <input type="text" name="from_station" required>
                
                <label for="to_station">To Station:</label>
                <input type="text" name="to_station" required>
                
                <label for="coach_class">Class:</label>
                <select name="coach_class" required>
                    <option value="Economy Class">Economy Class</option>
                    <option value="Business Class">Business Class</option>
                </select>
                
                <label for="luggage_details">Luggage Details:</label>
                <input type="text" name="luggage_details">
                
                <label for="price">Price:</label>
                <input type="number" name="price" step="0.01" required>
                
                <button type="submit" class="btn btn-add">Add Reservation</button>
            </form>
        </div>
    </div>

    <script>
        function showEditModal(reservation) {
            document.getElementById('edit_reservation_id').value = reservation.Reservation_ID;
            document.getElementById('edit_seat_number').value = reservation.Seat_Number;
            document.getElementById('edit_coach_class').value = reservation.Coach_Class;
            document.getElementById('edit_luggage_details').value = reservation.Luggage_Details;
            document.getElementById('editModal').style.display = 'block';
        }

        function showAddModal() {
            document.getElementById('addModal').style.display = 'block';
        }

        function closeModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
        }

        function confirmCancel(reservationId) {
            if (confirm('Are you sure you want to cancel this reservation?')) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.innerHTML = `
                    <input type="hidden" name="action" value="cancel">
                    <input type="hidden" name="reservation_id" value="${reservationId}">
                `;
                document.body.appendChild(form);
                form.submit();
            }
        }

        // Close modal when clicking outside
        window.onclick = function(event) {
            if (event.target.className === 'modal') {
                event.target.style.display = 'none';
            }
        }
    </script>
</body>
</html>