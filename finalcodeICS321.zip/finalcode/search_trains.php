<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

include 'includes/db_connection.php';

// Add user information to the page
$userFullName = $_SESSION['full_name'];
$loyaltyMiles = $_SESSION['loyalty_miles'];
$loyaltyClass = $_SESSION['loyalty_class'];

// Fetch stations for dropdowns
$stations = [];
$sql = "SELECT DISTINCT city FROM station";
$result = $conn->query($sql);
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $stations[] = $row['city'];
    }
}

// Fetch user reservations
$personId = $_SESSION['person_id'];
$reservations = [];
$sql = "
    SELECT 
        r.Reservation_ID, r.From_Station, r.To_Station, r.Coach_Class, r.Price,
        ts.Departure_Time, ts.Arrival_Time, t.English_Name AS Train_Name, r.Seat_Number, r.Reservation_Status
    FROM reservation r
    JOIN train_schedule ts ON r.Train_ID = ts.Train_ID
    JOIN train t ON ts.Train_ID = t.Train_ID
    WHERE r.Person_ID = ?
    ORDER BY r.Reservation_ID DESC
";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $personId);
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    $reservations[] = $row;
}

$stmt->close();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $from_station = $data['from_station'];
    $to_station = $data['to_station'];
    $outbound_date = $data['outbound_date'];
    $return_date = $data['return_date'];
    $is_round_trip = $data['is_round_trip'] ?? false;
    $travel_class = $data['travel_class'] ?? 'economy';

    // Store in session
    $_SESSION['from_station'] = $from_station;
    $_SESSION['to_station'] = $to_station;

    // Check seat availability
    $seat_limit = ($travel_class === 'economy') ? 75 : 100;
    $sql_seat_check = "
        SELECT COUNT(*) AS ReservedSeats
        FROM reservation
        WHERE Train_ID = ? AND Coach_Class = ? AND Reservation_Status = 'Confirmed'
    ";
    $stmt_seat_check = $conn->prepare($sql_seat_check);
    $stmt_seat_check->bind_param("is", $train_id, $travel_class);
    $stmt_seat_check->execute();
    $stmt_seat_check->bind_result($reservedSeats);
    $stmt_seat_check->fetch();
    $stmt_seat_check->close();

    if ($reservedSeats >= $seat_limit) {
        // All seats are reserved, offer to join the waiting list
        echo json_encode(['status' => 'full', 'message' => 'All seats are reserved. Would you like to join the waiting list?']);
    } else {
        // Proceed with booking
        // Query for outbound trip
        $sql_outbound = "
            SELECT DISTINCT
                ts.Schedule_ID, t.Train_ID, t.English_Name AS Train_Name, ts.Departure_Time, ts.Arrival_Time, ts.Economy_Price, ts.Business_Price
            FROM train_schedule ts
            JOIN train t ON ts.Train_ID = t.Train_ID
            WHERE t.Origin_City = ? AND t.Destination_City = ? AND ts.Date = ? AND ts.Economy_Price IS NOT NULL
        ";
        $stmt_outbound = $conn->prepare($sql_outbound);
        $stmt_outbound->bind_param("sss", $from_station, $to_station, $outbound_date);
        $stmt_outbound->execute();
        $result_outbound = $stmt_outbound->get_result();

        $outbound_trains = [];
        while ($row = $result_outbound->fetch_assoc()) {
            $outbound_trains[] = [
                'train_no' => $row['Train_ID'],
                'train_name' => $row['Train_Name'],
                'departure_time' => $row['Departure_Time'],
                'arrival_time' => $row['Arrival_Time'],
                'economy_price' => $row['Economy_Price'],
                'business_price' => $row['Business_Price']
            ];
        }

        $return_trains = [];
        if ($is_round_trip) {
            // Query for return trip
            $sql_return = "
                SELECT DISTINCT
                    ts.Schedule_ID, t.English_Name AS Train_Name, ts.Departure_Time, ts.Arrival_Time, ts.Economy_Price, ts.Business_Price
                FROM train_schedule ts
                JOIN train t ON ts.Train_ID = t.Train_ID
                WHERE t.Origin_City = ? AND t.Destination_City = ? AND ts.Date = ? AND ts.Economy_Price IS NOT NULL
            ";
            $stmt_return = $conn->prepare($sql_return);
            $stmt_return->bind_param("sss", $to_station, $from_station, $return_date);
            $stmt_return->execute();
            $result_return = $stmt_return->get_result();

            while ($row = $result_return->fetch_assoc()) {
                $return_trains[] = [
                    'train_no' => $row['Schedule_ID'],
                    'train_name' => $row['Train_Name'],
                    'departure_time' => $row['Departure_Time'],
                    'arrival_time' => $row['Arrival_Time'],
                    'economy_price' => $row['Economy_Price'],
                    'business_price' => $row['Business_Price']
                ];
            }
        }

        echo json_encode(['outbound' => $outbound_trains, 'return' => $return_trains]);
    }
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Saudi Railway System</title>
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #e0f7fa;
            color: #333;
        }

        h1, h2 {
            color: #007bff;
            text-align: center;
            margin-top: 20px;
        }

        form {
            max-width: 900px;
            margin: 40px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            display: flex;
            flex-wrap: wrap;
            justify-content: space-around;
            align-items: center;
        }

        .form-section {
            display: flex;
            flex-direction: column;
            align-items: flex-start;
            gap: 10px;
            width: 100%;
            flex: 1 1 45%;
            max-width: 400px;
            margin-top: 20px;
        }

        label {
            margin-bottom: 5px;
            font-weight: bold;
            color: #555;
        }

        select, input[type="text"] {
            padding: 10px 15px;
            border: none;
            border-radius: 10px;
            background-color: #fff;
            width: 100%;
            font-size: 16px;
            color: #333;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        button {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 12px 24px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s ease, transform 0.2s ease;
            margin: 10px;
            font-family: 'Roboto', sans-serif;
            font-weight: bold;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        button:hover {
            background-color: #0056b3;
            transform: scale(1.05);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        button:active {
            transform: scale(0.95);
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        #travel-options, #class-options {
            display: flex;
            justify-content: center;
            gap: 10px;
            width: 100%;
        }

        #travel-options button, #class-options button {
            background-color: #e0f7fa;
            border: 1px solid #ccc;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease, color 0.3s ease;
            font-size: 16px;
            color: #333;
            flex: 1;
            margin: 5px;
        }

        #travel-options button.active, #class-options button.active {
            background-color: #007bff;
            color: #fff;
            border-color: #007bff;
        }

        #travel-options button:hover, #class-options button:hover {
            background-color: #0056b3;
            color: #fff;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        #train-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: #fff;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        #train-table th {
            background-color: #007bff;
            color: white;
            padding: 12px;
            text-align: center;
        }

        #train-table td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: center;
        }

        #train-table tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        #train-table tr:hover {
            background-color: #ddd;
        }

        #train-table td button {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 5px 10px;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        #train-table td button:hover {
            background-color: #0056b3;
        }

        #passenger-button {
            background-color: #007bff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.2s ease;
            font-size: 16px;
            color: #fff !important;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        #passenger-button:hover {
            background-color: #0056b3;
            transform: scale(1.05);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        #passenger-button:active {
            transform: scale(0.95);
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        #passenger-button.active {
            background-color: #007bff;
            color: #fff !important;
            border: none;
        }

        #add-passenger-label {
            display: none; /* Initially hidden */
            color: #555;
            font-size: 14px;
            margin-top: 5px;
            text-align: center; /* Center the text */
        }

        #passenger-selection {
            position: relative;
            background-color: #fff;
            border: 1px solid #ccc;
            border-radius: 10px;
            padding: 15px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            z-index: 100;
            width: 220px;
            top: 50px;
            left: 0;
            opacity: 0;
            visibility: hidden;
            transition: opacity 0.3s ease, visibility 0.3s ease;
        }
        #passenger-selection.show {
            opacity: 1;
            visibility: visible;
        }
        .passenger-type {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
            font-size: 16px;
        }
        .counter {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .counter button {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 5px 10px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s ease, transform 0.2s ease;
        }
        .counter span {
            min-width: 20px;
            text-align: center;
        }
        button {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px 20px;
            font-size: 18px;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s ease, transform 0.2s ease;
        }
        button:hover {
            background-color: #0056b3;
            transform: scale(1.05);
        }
        button:active {
            transform: scale(0.95);
        }
        .apply-button {
            width: 100%;
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px;
            cursor: pointer;
            border-radius: 5px;
            text-align: center;
        }
        .apply-button:hover {
            background-color: #0056b3;
        }
        #total-passengers {
            transition: opacity 0.1s ease;
            opacity: 1;
            color: white;
        }
        .fade-out {
            opacity: 0;
        }
        select {
            padding: 10px 15px;
            font-size: 16px;
            border: 1px solid #ccc;
        }
        #train-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        #train-table th {
            background-color: #333;
            color: white;
            padding: 8px;
            text-align: center;
        }
        #train-table td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: center;
        }
        #train-table tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        #train-table tr:hover {
            background-color: #ddd;
        }
        #train-table td button {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 5px 10px;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }
        #train-table td button:hover {
            background-color: #0056b3;
        }
        #book-train-button {
            margin-top: 20px;
            background-color: #007bff;
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 18px;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s ease, transform 0.2s ease;
        }
        #book-train-button:hover {
            background-color: #0056b3;
            transform: scale(1.05);
        }
        /* Style for class selection buttons */
        #class-options button {
            background-color: #e0f7fa;
            border: 1px solid #ccc;
            padding: 10px 20px;
            margin-right: 10px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease, color 0.3s ease;
            font-size: 16px;
            color: #333;
        }

        #class-options button.active {
            background-color: #007bff;
            color: #fff;
            border-color: #007bff;
        }

        #class-options button:hover {
            background-color: #0056b3;
            color: #fff;
        }

        /* Align the search button to the right */
        .button-section {
            display: flex;
            justify-content: flex-start;
            width: 100%;
            margin-top: 20px;
        }

        .button-section button {
            width: 200px;
            padding: 15px 30px;
            font-size: 18px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.2s ease;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            margin: 0 20px;
        }

        .button-section button:hover {
            background-color: #0056b3;
            transform: scale(1.05);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        .button-section button:active {
            transform: scale(0.95);
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .form-section:nth-child(3) {
            margin-top: 0;
        }

        .user-info {
            background-color: #fff;
            padding: 15px;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .user-info p {
            margin: 5px 0;
            color: #333;
        }

        .user-info a {
            display: inline-block;
            margin-top: 10px;
            padding: 5px 10px;
            background-color: #007bff;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .user-info a:hover {
            background-color: #0056b3;
        }

        .logout-btn {
            display: inline-block;
            margin-top: 10px;
            padding: 5px 10px;
            background-color: #dc3545;
            color: #fff !important;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s ease, transform 0.2s ease;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .logout-btn:hover {
            background-color: #c82333;
            transform: scale(1.05);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        .logout-btn:active {
            transform: scale(0.95);
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .user-buttons {
            display: flex;
            gap: 10px;
            justify-content: flex-end;
            margin-top: 10px;
        }

        .reservation-btn {
            display: inline-block;
            padding: 5px 10px;
            background-color: #28a745;
            color: #fff !important;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s ease, transform 0.2s ease;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .reservation-btn:hover {
            background-color: #218838;
            transform: scale(1.05);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        .reservation-btn:active {
            transform: scale(0.95);
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        #reservations-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: #fff;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        #reservations-table th {
            background-color: #007bff;
            color: white;
            padding: 12px;
            text-align: center;
        }

        #reservations-table td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: center;
        }

        #reservations-table tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        #reservations-table tr:hover {
            background-color: #ddd;
        }

        #view-options {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin: 20px 0;
            padding: 10px;
        }

        #view-options button {
            background-color: #e0f7fa;
            border: 1px solid #ccc;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease, color 0.3s ease, transform 0.2s ease;
            font-size: 16px;
            color: #333;
            flex: 0 1 200px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        #view-options button.active {
            background-color: #007bff;
            color: #fff;
            border-color: #007bff;
        }

        #view-options button:hover {
            background-color: #0056b3;
            color: #fff;
            transform: scale(1.05);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        #view-options button:active {
            transform: scale(0.95);
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        #passenger-selection table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: #fff;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        #passenger-selection th, #passenger-selection td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: center;
        }

        #passenger-selection th {
            background-color: #007bff;
            color: white;
        }

        #passenger-selection tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        #passenger-selection tr:hover {
            background-color: #ddd;
        }

        #report-results {
            margin-bottom: 200px;
        }

        #report-results table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: #fff;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        #report-results th, #report-results td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: center;
        }

        #report-results th {
            background-color: #007bff;
            color: white;
        }

        #report-results tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        #report-results tr:hover {
            background-color: #ddd;
        }

        /* Add this CSS to minimize the space between buttons */
        #travel-options button, #class-options button {
            margin: 5px; /* Adjust this value to minimize space */
        }

        .view-ticket-btn {
            background-color: #007bff;
            color: white;
            padding: 5px 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .view-ticket-btn:hover {
            background-color: #0056b3;
        }
    </style>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
</head>
<body>
    <div class="user-info" style="position: absolute; top: 20px; right: 20px; text-align: right;">
        <p>Welcome, <?php echo htmlspecialchars($userFullName); ?></p>
        <p>Loyalty Miles: <?php echo number_format($loyaltyMiles); ?></p>
        <p>Loyalty Class: <?php echo $loyaltyClass; ?></p>
        <a href="logout.php" class="logout-btn">Logout</a>
    </div>
    <div id="view-options">
        <button type="button" id="book-train" class="active" onclick="selectViewOption('book-train')">Book Train</button>
        <button type="button" id="my-reservations" onclick="selectViewOption('my-reservations')">My Reservations</button>
    </div>
    <h1>Saudi Railway System</h1>
    <div id="passenger-functions">
        <form id="search-trains-form">
            <div class="form-section">
                <label for="from-station">From</label>
                <select id="from-station" name="from_station" required>
                    <?php foreach ($stations as $station): ?>
                        <option value="<?= $station ?>"><?= $station ?></option>
                    <?php endforeach; ?>
                </select>
                <span>→</span>
                <label for="to-station">To</label>
                <select id="to-station" name="to_station" required>
                    <?php foreach ($stations as $station): ?>
                        <option value="<?= $station ?>"><?= $station ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-section">
                <div id="travel-options">
                    <button type="button" id="one-way" class="active" onclick="selectTravelOption('one-way')">One Way</button>
                    <button type="button" id="round-trip" onclick="selectTravelOption('round-trip')">Round Trip</button>
                </div>
                <div class="date-inputs">
                    <label for="travel-date">Travel Dates</label>
                    <input type="text" id="travel-date" name="travel_date" required>
                </div>
                <div id="passenger-button" onclick="togglePassengerDropdown()">
                    Passengers: <span id="total-passengers">1 Adult</span>
                </div>
                <div id="add-passenger-label" style="display: none; color: #555; font-size: 14px; margin-top: 5px;">
                    Click to add more passengers
                </div>
                <div id="passenger-selection" class="passenger-dropdown">
                    <div class="passenger-type adult show">
                        <span>Adult (Age 12+)</span>
                        <div class="counter">
                            <button type="button" onclick="decrement('adult')">-</button>
                            <span id="adult-count">1</span>
                            <button type="button" onclick="increment('adult')">+</button>
                        </div>
                    </div>
                    <div class="passenger-type child">
                        <span>Child (Age 2-11)</span>
                        <div class="counter">
                            <button type="button" onclick="decrement('child')">-</button>
                            <span id="child-count">0</span>
                            <button type="button" onclick="increment('child')">+</button>
                        </div>
                    </div>
                    <div class="passenger-type infant">
                        <span>Infant (Age 0-1)</span>
                        <div class="counter">
                            <button type="button" onclick="decrement('infant')">-</button>
                            <span id="infant-count">0</span>
                            <button type="button" onclick="increment('infant')">+</button>
                        </div>
                    </div>
                    <button type="button" class="apply-button" onclick="applyPassengerSelection()">Apply</button>
                </div>
            </div>
            <div class="form-section">
                <div id="class-options">
                    <button type="button" id="economy-class" class="active" onclick="selectClassOption('economy')">Economy</button>
                    <button type="button" id="business-class" onclick="selectClassOption('business')">Business</button>
                </div>
            </div>
            <div class="form-section button-section">
                <button type="submit">Search Trains</button>
            </div>
        </form>
        <div id="train-results">
            <h2>Available Trains:</h2>
            <table id="train-table">
                <thead>
                    <tr>
                        <th>Select</th>
                        <th>Train Name</th>
                        <th>Departure</th>
                        <th>Arrival</th>
                        <th>Business Seats</th>
                        <th>Economy Seats</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Train data will be inserted here -->
                </tbody>
            </table>

            <div id="return-train-section" style="display: none;">
                <h2>Return Trains:</h2>
                <table id="train-table">
                    <thead>
                        <tr>
                            <th>Select</th>
                            <th>Train Name</th>
                            <th>Departure</th>
                            <th>Arrival</th>
                            <th>Business Seats</th>
                            <th>Economy Seats</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!-- Return train data will be inserted here -->
                    </tbody>
                </table>
            </div>

            <button id="book-train-button">Book Selected Train(s)</button>
        </div>
    </div>
    <div id="reservations-section" style="display: none;">
        <h2>My Reservations</h2>
        <?php if (empty($reservations)): ?>
            <p>No reservations found.</p>
        <?php else: ?>
            <table id="reservations-table">
                <thead>
                    <tr>
                        <th>Reservation ID</th>
                        <th>Train Name</th>
                        <th>From</th>
                        <th>To</th>
                        <th>Departure Time</th>
                        <th>Arrival Time</th>
                        <th>Class</th>
                        <th>Seat Number</th>
                        <th>Status</th>
                        <th>Price</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($reservations as $reservation): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($reservation['Reservation_ID']); ?></td>
                            <td><?php echo htmlspecialchars($reservation['Train_Name']); ?></td>
                            <td><?php echo htmlspecialchars($reservation['From_Station']); ?></td>
                            <td><?php echo htmlspecialchars($reservation['To_Station']); ?></td>
                            <td><?php echo htmlspecialchars($reservation['Departure_Time']); ?></td>
                            <td><?php echo htmlspecialchars($reservation['Arrival_Time']); ?></td>
                            <td><?php echo htmlspecialchars($reservation['Coach_Class']); ?></td>
                            <td><?php echo htmlspecialchars($reservation['Seat_Number']); ?></td>
                            <td><?php echo htmlspecialchars($reservation['Reservation_Status']); ?></td>
                            <td><?php echo number_format($reservation['Price'], 2); ?> SAR</td>
                            <td><a href="view_ticket.php?reservation_id=<?php echo $reservation['Reservation_ID']; ?>" class="view-ticket-btn">View Ticket</a></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
    <div id="system-functions">
        <h2>System Functions</h2>
        <button id="generate-reports">Available Trains Today</button>
        <div id="report-results"></div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script>
        // Initialize flatpickr with default settings
        let travelDatePicker = flatpickr("#travel-date", {
            mode: "single", // Default to single date selection
            minDate: "today"
        });

        function selectTravelOption(option) {
            const oneWayButton = document.getElementById('one-way');
            const roundTripButton = document.getElementById('round-trip');

            if (option === 'one-way') {
                oneWayButton.classList.add('active');
                roundTripButton.classList.remove('active');
                travelDatePicker.set('mode', 'single'); // Set to single date selection
            } else if (option === 'round-trip') {
                roundTripButton.classList.add('active');
                oneWayButton.classList.remove('active');
                travelDatePicker.set('mode', 'range'); // Set to range date selection
            }
        }

        function selectClassOption(option) {
            const economyButton = document.getElementById('economy-class');
            const businessButton = document.getElementById('business-class');

            if (option === 'economy') {
                economyButton.classList.add('active');
                businessButton.classList.remove('active');
            } else if (option === 'business') {
                businessButton.classList.add('active');
                economyButton.classList.remove('active');
            }
        }

        document.getElementById('search-trains-form').addEventListener('submit', function(event) {
            event.preventDefault();
            const fromStation = document.getElementById('from-station').value;
            const toStation = document.getElementById('to-station').value;
            const travelDates = document.getElementById('travel-date').value.split(' to ');
            const outboundDate = travelDates[0];
            const returnDate = travelDates[1] || outboundDate;
            const isRoundTrip = document.getElementById('round-trip').classList.contains('active');
            const selectedClass = document.getElementById('business-class').classList.contains('active') ? 'business' : 'economy';

            fetch('search_trains.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    from_station: fromStation,
                    to_station: toStation,
                    outbound_date: outboundDate,
                    return_date: returnDate,
                    is_round_trip: isRoundTrip,
                    travel_class: selectedClass
                })
            })
            .then(response => response.json())
            .then(data => {
                const tbody = document.querySelector('#train-table tbody');
                tbody.innerHTML = ''; // Clear previous results
                if (data.outbound.length === 0) {
                    tbody.innerHTML = `<tr><td colspan="6">No trains available on the selected date.</td></tr>`;
                } else {
                    data.outbound.forEach(train => {
                        const row = document.createElement('tr');
                        row.innerHTML = `
                            <td><input type="radio" name="selected_train" value="${train.train_no}"></td>
                            <td>${train.train_name}</td>
                            <td>${train.departure_time}</td>
                            <td>${train.arrival_time}</td>
                            <td>${train.business_price || 'N/A'}</td>
                            <td>${train.economy_price || 'N/A'}</td>
                        `;
                        tbody.appendChild(row);
                    });
                }

                if (isRoundTrip) {
                    const returnTbody = document.querySelector('#return-train-section tbody');
                    returnTbody.innerHTML = ''; // Clear previous results
                    document.getElementById('return-train-section').style.display = 'block';
                    if (data.return.length === 0) {
                        returnTbody.innerHTML = `<tr><td colspan="6">No return trains available on the selected date.</td></tr>`;
                    } else {
                        data.return.forEach(train => {
                            const row = document.createElement('tr');
                            row.innerHTML = `
                                <td><input type="radio" name="selected_return_train" value="${train.train_no}"></td>
                                <td>${train.train_name}</td>
                                <td>${train.departure_time}</td>
                                <td>${train.arrival_time}</td>
                                <td>${train.business_price || 'N/A'}</td>
                                <td>${train.economy_price || 'N/A'}</td>
                            `;
                            returnTbody.appendChild(row);
                        });
                    }
                } else {
                    document.getElementById('return-train-section').style.display = 'none';
                }
            })
            .catch(error => {
                const tbody = document.querySelector('#train-table tbody');
                tbody.innerHTML = `<tr><td colspan="6">Error: ${error.message}</td></tr>`;
            });
        });

        document.getElementById('book-train-button').addEventListener('click', function() {
            const selectedTrain = document.querySelector('input[name="selected_train"]:checked');
            const selectedReturnTrain = document.querySelector('input[name="selected_return_train"]:checked');
            const isRoundTrip = document.getElementById('round-trip').classList.contains('active');

            if (selectedTrain && (!isRoundTrip || (isRoundTrip && selectedReturnTrain))) {
                const outboundScheduleId = selectedTrain.value;
                const returnScheduleId = isRoundTrip ? selectedReturnTrain.value : null;
                let bookingUrl = `complete_booking.php?selected_train_id=${outboundScheduleId}`;
                if (returnScheduleId) {
                    bookingUrl += `&return_schedule_id=${returnScheduleId}`;
                }
                // Pass passenger details as well
                const passengerCount = document.getElementById('total-passengers').textContent;
                bookingUrl += `&passenger_count=${passengerCount}`;
                window.location.href = bookingUrl;
            } else {
                alert('Please select a train for each leg of your trip.');
            }
        });

        function togglePassengerDropdown() {
            const dropdown = document.getElementById('passenger-selection');
            const label = document.getElementById('add-passenger-label');
            dropdown.classList.toggle('show');
            label.style.display = dropdown.classList.contains('show') ? 'block' : 'none';
        }

        function increment(type) {
            const countElement = document.getElementById(`${type}-count`);
            let count = parseInt(countElement.textContent);
            countElement.textContent = count + 1;
            updateTotalPassengers();
            togglePassengerType(type);
        }

        function decrement(type) {
            const countElement = document.getElementById(`${type}-count`);
            let count = parseInt(countElement.textContent);
            if (count > 0) {
                countElement.textContent = count - 1;
            }
            updateTotalPassengers();
            togglePassengerType(type);
        }

        function updateTotalPassengers() {
            const adultCount = parseInt(document.getElementById('adult-count').textContent);
            const childCount = parseInt(document.getElementById('child-count').textContent);
            const infantCount = parseInt(document.getElementById('infant-count').textContent);
            const totalPassengersElement = document.getElementById('total-passengers');
            setTimeout(() => {
                let totalText = [];
                if (adultCount > 0) totalText.push(`${adultCount} Adult${adultCount > 1 ? 's' : ''}`);
                if (childCount > 0) totalText.push(`${childCount} Child${childCount > 1 ? 'ren' : ''}`);
                if (infantCount > 0) totalText.push(`${infantCount} Infant${infantCount > 1 ? 's' : ''}`);
                totalPassengersElement.textContent = totalText.join(', ');
                totalPassengersElement.classList.remove('fade-out');
            }, 300);
        }

        function togglePassengerType(type) {
            const passengerTypeElement = document.querySelector(`.passenger-type.${type}`);
            const count = parseInt(document.getElementById(`${type}-count`).textContent);
            if (count > 0) {
                passengerTypeElement.classList.add('show');
            } else {
                passengerTypeElement.classList.remove('show');
            }
        }

        function applyPassengerSelection() {
            togglePassengerDropdown();
        }

        document.getElementById('generate-reports').addEventListener('click', function() {
            fetch('generate_reports.php')
            .then(response => response.json())
            .then(data => {
                const reportDiv = document.getElementById('report-results');
                reportDiv.innerHTML = ''; // Clear previous reports

                if (data.length === 0) {
                    reportDiv.innerHTML = '<p>No active trains today.</p>';
                } else {
                    const table = document.createElement('table');
                    table.style.width = '100%';
                    table.style.borderCollapse = 'collapse';
                    table.innerHTML = `
                        <thead>
                            <tr>
                                <th>Train Name</th>
                                <th>From</th>
                                <th>To</th>
                                <th>Departure Time</th>
                                <th>Arrival Time</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${data.map(train => `
                                <tr>
                                    <td>${train.Train_Name}</td>
                                    <td>${train.From_City}</td>
                                    <td>${train.To_City}</td>
                                    <td>${train.Departure_Time}</td>
                                    <td>${train.Arrival_Time}</td>
                                </tr>
                            `).join('')}
                        </tbody>
                    `;
                    reportDiv.appendChild(table);
                }
            })
            .catch(error => {
                console.error('Error fetching reports:', error);
            });
        });

        const cityGroups = {
            riyadh: ['Dammam', 'Hofuf', 'Hail', 'Jauf', 'Al-Qassim', 'Majmaah', 'Qurayyat'],
            west: ['Jeddah', 'Makkah', 'Medina'],
            east: ['Dammam', 'Hofuf'],
            north: ['Hail', 'Jauf', 'Al-Qassim', 'Majmaah', 'Qurayyat']
        };

        function updateToCities(fromCity) {
            const toStationSelect = document.getElementById('to-station');
            toStationSelect.innerHTML = ''; // Clear existing options

            let availableCities = [];

            if (fromCity === 'Riyadh') {
                availableCities = cityGroups.east.concat(cityGroups.north);
            } else if (cityGroups.west.includes(fromCity)) {
                availableCities = cityGroups.west;
            } else if (cityGroups.east.includes(fromCity)) {
                availableCities = cityGroups.east.concat(['Riyadh']);
            } else if (cityGroups.north.includes(fromCity)) {
                availableCities = cityGroups.north.concat(['Riyadh']);
            }

            // Remove the "From" city from the available "To" cities
            availableCities = availableCities.filter(city => city !== fromCity);

            // Remove duplicates by converting to a Set and back to an array
            availableCities = [...new Set(availableCities)];

            availableCities.forEach(city => {
                const option = document.createElement('option');
                option.value = city;
                option.textContent = city;
                toStationSelect.appendChild(option);
            });
        }

        document.getElementById('from-station').addEventListener('change', function() {
            updateToCities(this.value);
        });

        // Initialize the "To" dropdown based on the default "From" city
        document.addEventListener('DOMContentLoaded', function() {
            const fromStation = document.getElementById('from-station').value;
            updateToCities(fromStation);
        });

        function selectViewOption(option) {
            const bookTrainBtn = document.getElementById('book-train');
            const myReservationsBtn = document.getElementById('my-reservations');
            const searchForm = document.getElementById('search-trains-form');
            const trainResults = document.getElementById('train-results');
            const reservationsSection = document.getElementById('reservations-section');

            if (option === 'book-train') {
                bookTrainBtn.classList.add('active');
                myReservationsBtn.classList.remove('active');
                searchForm.style.display = 'flex';
                trainResults.style.display = 'block';
                reservationsSection.style.display = 'none';
            } else if (option === 'my-reservations') {
                myReservationsBtn.classList.add('active');
                bookTrainBtn.classList.remove('active');
                searchForm.style.display = 'none';
                trainResults.style.display = 'none';
                reservationsSection.style.display = 'block';
            }
        }

        // Initialize the view on page load
        document.addEventListener('DOMContentLoaded', function() {
            selectViewOption('book-train');
        });
    </script>
</body>
</html>
