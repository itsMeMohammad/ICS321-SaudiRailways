<?php
session_start();
require_once 'includes/db_connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    
    // Modified SQL to join with person and passenger tables
    $stmt = $conn->prepare("
        SELECT 
            pu.id,
            pu.username,
            pu.password,
            pu.Person_ID,
            p.FName,
            p.LName,
            pa.Loyalty_Miles,
            pa.Loyalty_Classs
        FROM passenger_users pu
        JOIN person p ON pu.Person_ID = p.Person_ID
        JOIN passenger pa ON p.Person_ID = pa.Person_ID
        WHERE pu.username = ?
    ");
    
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();
        
        // For this example, we're using plain text password comparison
        // In production, you should use password_verify()
        if ($password === $user['password']) {
            session_regenerate_id(true);
            
            // Set session variables
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['person_id'] = $user['Person_ID'];
            $_SESSION['full_name'] = $user['FName'] . ' ' . $user['LName'];
            $_SESSION['loyalty_miles'] = $user['Loyalty_Miles'];
            $_SESSION['loyalty_class'] = $user['Loyalty_Classs'];
            
            // Redirect to search trains page
            header("Location: search_trains.php");
            exit();
        }
    }
    $error = "Invalid username or password";
    $stmt->close();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>SAR Login</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            background-color: #808080;
            font-family: Arial, sans-serif;
        }

        .logo {
            width: 200px;
            margin-bottom: 40px;
        }

        .login-container {
            width: 100%;
            max-width: 400px;
            padding: 20px;
        }

        .input-group {
            margin-bottom: 20px;
            width: 100%;
        }

        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            background-color: rgba(255, 255, 255, 0.1);
            color: #333;
            font-size: 14px;
        }

        .login-btn {
            width: 100%;
            padding: 12px;
            background-color: #fff;
            border: none;
            border-radius: 4px;
            color: #333;
            font-weight: bold;
            cursor: pointer;
            margin-bottom: 15px;
        }

        .admin-login-btn {
            width: 100%;
            padding: 12px;
            background-color: #fff;
            border: none;
            border-radius: 4px;
            color: #0099cc;
            font-weight: bold;
            cursor: pointer;
        }

        .forgot-password {
            text-align: center;
            color: #fff;
            text-decoration: none;
            font-size: 14px;
            margin: 10px 0;
        }

        .forgot-password:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <img src="/images/SAR Logo.png" alt="SAR Logo" class="logo">
    
    <div class="login-container">
        <?php if(isset($error)) { echo "<p style='color: red; text-align: center;'>$error</p>"; } ?>
        
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <div class="input-group">
                <input type="text" name="username" placeholder="USERNAME" required>
            </div>
            <div class="input-group">
                <input type="password" name="password" placeholder="PASSWORD" required>
            </div>
            <button type="submit" class="login-btn">LOGIN</button>
        </form>
        
        <a href="#" class="forgot-password">Forgot password?</a>
        
        <button onclick="window.location.href='staff_login.php'" class="admin-login-btn">STAFF MEMBER LOGIN</button>
    </div>
</body>
</html>