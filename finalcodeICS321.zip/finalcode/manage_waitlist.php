<?php
session_start();
require_once 'includes/db_connection.php';

// Check if user is logged in as admin
if (!isset($_SESSION['staff_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../staff_login.php");
    exit();
}

// Handle Actions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'promote':
                promoteFromWaitlist();
                break;
            case 'remove':
                removeFromWaitlist();
                break;
            case 'add':
                addToWaitlist();
                break;
        }
    }
}

// Function to promote passenger from waitlist
function promoteFromWaitlist() {
    global $conn;
    try {
        $conn->begin_transaction();

        $waiting_list_id = $_POST['waiting_list_id'];
        $person_id = $_POST['person_id'];
        $train_id = $_POST['train_id'];
        $seat_number = $_POST['seat_number'];
        
        // Get passenger details
        $stmt = $conn->prepare("
            SELECT p.FName, p.LName, w.From_Station, w.To_Station, w.Coach_Class
            FROM waiting_list w
            JOIN person p ON w.Person_ID = p.Person_ID
            WHERE w.Waiting_List_ID = ?
        ");
        $stmt->bind_param("i", $waiting_list_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $passenger = $result->fetch_assoc();

        // Create new reservation
        $stmt = $conn->prepare("
            INSERT INTO reservation (
                Seat_Number, Passenger_ID, Train_ID, From_Station, 
                To_Station, Coach_Class, Payment_Status, Reservation_Status, 
                Person_ID, Name
            ) VALUES (?, ?, ?, ?, ?, ?, 'Pending', 'Confirmed', ?, ?)
        ");
        
        $name = $passenger['FName'] . ' ' . $passenger['LName'];
        $stmt->bind_param(
            "iiisssis",
            $seat_number,
            $person_id,
            $train_id,
            $passenger['From_Station'],
            $passenger['To_Station'],
            $passenger['Coach_Class'],
            $person_id,
            $name
        );
        $stmt->execute();

        // Remove from waiting list
        $stmt = $conn->prepare("DELETE FROM waiting_list WHERE Waiting_List_ID = ?");
        $stmt->bind_param("i", $waiting_list_id);
        $stmt->execute();

        // Remove from added_to
        $stmt = $conn->prepare("DELETE FROM added_to WHERE Waiting_List_ID = ?");
        $stmt->bind_param("i", $waiting_list_id);
        $stmt->execute();

        $conn->commit();
        $_SESSION['success_message'] = "Passenger successfully promoted from waitlist.";
    } catch (Exception $e) {
        $conn->rollback();
        $_SESSION['error_message'] = "Error promoting passenger: " . $e->getMessage();
    }
}

// Function to remove from waitlist
function removeFromWaitlist() {
    global $conn;
    try {
        $conn->begin_transaction();

        $waiting_list_id = $_POST['waiting_list_id'];

        // Remove from waiting list
        $stmt = $conn->prepare("DELETE FROM waiting_list WHERE Waiting_List_ID = ?");
        $stmt->bind_param("i", $waiting_list_id);
        $stmt->execute();

        // Remove from added_to
        $stmt = $conn->prepare("DELETE FROM added_to WHERE Waiting_List_ID = ?");
        $stmt->bind_param("i", $waiting_list_id);
        $stmt->execute();

        $conn->commit();
        $_SESSION['success_message'] = "Passenger removed from waitlist.";
    } catch (Exception $e) {
        $conn->rollback();
        $_SESSION['error_message'] = "Error removing from waitlist: " . $e->getMessage();
    }
}

// Function to add to waitlist
function addToWaitlist() {
    global $conn;
    try {
        $conn->begin_transaction();

        $person_id = $_POST['person_id'];
        $train_id = $_POST['train_id'];
        $from_station = $_POST['from_station'];
        $to_station = $_POST['to_station'];
        $coach_class = $_POST['coach_class'];

        // Insert into waiting list
        $stmt = $conn->prepare("
            INSERT INTO waiting_list (
                Person_ID, Train_ID, From_Station, To_Station, Coach_Class
            ) VALUES (?, ?, ?, ?, ?)
        ");
        $stmt->bind_param("iisss", $person_id, $train_id, $from_station, $to_station, $coach_class);
        $stmt->execute();
        
        $waiting_list_id = $conn->insert_id;

        // Add to added_to table
        $stmt = $conn->prepare("
            INSERT INTO added_to (Person_ID, Waiting_List_ID, Temporary_Hold_Date) 
            VALUES (?, ?, CURDATE())
        ");
        $stmt->bind_param("ii", $person_id, $waiting_list_id);
        $stmt->execute();

        $conn->commit();
        $_SESSION['success_message'] = "Passenger added to waitlist successfully.";
    } catch (Exception $e) {
        $conn->rollback();
        $_SESSION['error_message'] = "Error adding to waitlist: " . $e->getMessage();
    }
}

// Get all waitlisted passengers
$waitlist_query = "
    SELECT 
        w.Waiting_List_ID,
        p.Person_ID,
        p.FName,
        p.LName,
        w.Train_ID,
        t.English_Name as train_name,
        w.From_Station,
        w.To_Station,
        w.Coach_Class,
        a.Temporary_Hold_Date
    FROM waiting_list w
    JOIN person p ON w.Person_ID = p.Person_ID
    JOIN train t ON w.Train_ID = t.Train_ID
    JOIN added_to a ON w.Waiting_List_ID = a.Waiting_List_ID
    ORDER BY a.Temporary_Hold_Date ASC";
$waitlist_result = $conn->query($waitlist_query);

// Get all trains for dropdown
$trains_query = "SELECT Train_ID, English_Name FROM train";
$trains_result = $conn->query($trains_query);

// Get all passengers for dropdown
$passengers_query = "SELECT p.Person_ID, p.FName, p.LName FROM person p JOIN passenger pa ON p.Person_ID = pa.Person_ID";
$passengers_result = $conn->query($passengers_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Waitlist - Admin Panel</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f4f4f4;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background-color: white;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: left;
        }
        th {
            background-color: #007bff;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        .btn {
            padding: 5px 10px;
            border: none;
            border-radius: 3px;
            cursor: pointer;
            color: white;
            text-decoration: none;
            margin: 2px;
        }
        .btn-promote { background-color: #28a745; }
        .btn-remove { background-color: #dc3545; }
        .btn-add { background-color: #007bff; }
        .message {
            padding: 10px;
            margin-bottom: 10px;
            border-radius: 3px;
        }
        .success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
        }
        .modal-content {
            background-color: white;
            margin: 15% auto;
            padding: 20px;
            border-radius: 5px;
            width: 50%;
        }
        .close {
            float: right;
            cursor: pointer;
            font-size: 24px;
        }
        form {
            display: grid;
            gap: 10px;
        }
        input, select {
            padding: 5px;
            border: 1px solid #ddd;
            border-radius: 3px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Manage Waitlist</h1>

        <?php if (isset($_SESSION['success_message'])): ?>
            <div class="message success">
                <?php 
                echo $_SESSION['success_message'];
                unset($_SESSION['success_message']);
                ?>
            </div>
        <?php endif; ?>

        <?php if (isset($_SESSION['error_message'])): ?>
            <div class="message error">
                <?php 
                echo $_SESSION['error_message'];
                unset($_SESSION['error_message']);
                ?>
            </div>
        <?php endif; ?>

        <button class="btn btn-add" onclick="showAddModal()">Add to Waitlist</button>

        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Passenger Name</th>
                    <th>Train</th>
                    <th>From</th>
                    <th>To</th>
                    <th>Class</th>
                    <th>Hold Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while($row = $waitlist_result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $row['Waiting_List_ID']; ?></td>
                    <td><?php echo $row['FName'] . ' ' . $row['LName']; ?></td>
                    <td><?php echo $row['train_name']; ?></td>
                    <td><?php echo $row['From_Station']; ?></td>
                    <td><?php echo $row['To_Station']; ?></td>
                    <td><?php echo $row['Coach_Class']; ?></td>
                    <td><?php echo $row['Temporary_Hold_Date']; ?></td>
                    <td>
                        <button class="btn btn-promote" onclick="showPromoteModal(<?php echo htmlspecialchars(json_encode($row)); ?>)">Promote</button>
                        <button class="btn btn-remove" onclick="confirmRemove(<?php echo $row['Waiting_List_ID']; ?>)">Remove</button>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>

    <!-- Add to Waitlist Modal -->
    <div id="addModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal('addModal')">&times;</span>
            <h2>Add to Waitlist</h2>
            <form method="POST">
                <input type="hidden" name="action" value="add">
                
                <label for="person_id">Passenger:</label>
                <select name="person_id" required>
                    <?php 
                    $passengers_result->data_seek(0);
                    while($passenger = $passengers_result->fetch_assoc()): 
                    ?>
                        <option value="<?php echo $passenger['Person_ID']; ?>">
                            <?php echo $passenger['FName'] . ' ' . $passenger['LName']; ?>
                        </option>
                    <?php endwhile; ?>
                </select>

                <label for="train_id">Train:</label>
                <select name="train_id" required>
                    <?php 
                    $trains_result->data_seek(0);
                    while($train = $trains_result->fetch_assoc()): 
                    ?>
                        <option value="<?php echo $train['Train_ID']; ?>">
                            <?php echo $train['English_Name']; ?>
                        </option>
                    <?php endwhile; ?>
                </select>

                <label for="from_station">From Station:</label>
                <input type="text" name="from_station" required>

                <label for="to_station">To Station:</label>
                <input type="text" name="to_station" required>

                <label for="coach_class">Class:</label>
                <select name="coach_class" required>
                    <option value="Economy Class">Economy Class</option>
                    <option value="Business Class">Business Class</option>
                </select>

                <button type="submit" class="btn btn-add">Add to Waitlist</button>
            </form>
        </div>
    </div>

    <!-- Promote Modal -->
    <div id="promoteModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal('promoteModal')">&times;</span>
            <h2>Promote from Waitlist</h2>
            <form method="POST">
                <input type="hidden" name="action" value="promote">
                <input type="hidden" name="waiting_list_id" id="promote_waiting_list_id">
                <input type="hidden" name="person_id" id="promote_person_id">
                <input type="hidden" name="train_id" id="promote_train_id">

                <label for="seat_number">Seat Number:</label>
                <input type="number" name="seat_number" required>

                <button type="submit" class="btn btn-promote">Promote Passenger</button>
            </form>
        </div>
    </div>

    <script>
        function showAddModal() {
            document.getElementById('addModal').style.display = 'block';
        }

        function showPromoteModal(waitlist) {
            document.getElementById('promote_waiting_list_id').value = waitlist.Waiting_List_ID;
            document.getElementById('promote_person_id').value = waitlist.Person_ID;
            document.getElementById('promote_train_id').value = waitlist.Train_ID;
            document.getElementById('promoteModal').style.display = 'block';
        }

        function closeModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
        }

        function confirmRemove(waitlistId) {
            if (confirm('Are you sure you want to remove this passenger from the waitlist?')) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.innerHTML = `
                    <input type="hidden" name="action" value="remove">
                    <input type="hidden" name="waiting_list_id" value="${waitlistId}">
                `;
                document.body.appendChild(form);
                form.submit();
            }
        }

        // Close modal when clicking outside
        window.onclick = function(event) {
            if (event.target.className === 'modal') {
                event.target.style.display = 'none';
            }
        }
    </script>
</body>
</html>