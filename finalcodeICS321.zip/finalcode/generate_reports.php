<?php
include 'includes/db_connection.php';

$sql = "
    SELECT 
        ts.Schedule_ID, 
        t.English_Name AS Train_Name, 
        ts.Departure_Time, 
        ts.Arrival_Time, 
        t.Origin_City AS From_City,
        t.Destination_City AS To_City
    FROM 
        train_schedule ts
    JOIN 
        train t ON ts.Train_ID = t.Train_ID
    WHERE 
        ts.Date = CURDATE();
";

$result = $conn->query($sql);

if (!$result) {
    echo "SQL Error: " . $conn->error;
    exit();
}

$reports = [];
while ($row = $result->fetch_assoc()) {
    $reports[] = [
        'Train_Name' => $row['Train_Name'],
        'Departure_Time' => $row['Departure_Time'],
        'Arrival_Time' => $row['Arrival_Time'],
        'From_City' => $row['From_City'],
        'To_City' => $row['To_City']
    ];
}

echo json_encode($reports);
?>
