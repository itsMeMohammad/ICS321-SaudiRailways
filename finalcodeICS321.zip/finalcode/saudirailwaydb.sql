-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 15, 2024 at 10:54 AM
-- Server version: 5.7.17
-- PHP Version: 8.2.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `saudirailwaydb`
--

-- --------------------------------------------------------

--
-- Table structure for table `added_to`
--

CREATE TABLE `added_to` (
  `Person_ID` int(11) NOT NULL,
  `Waiting_List_ID` int(11) NOT NULL,
  `Temporary_Hold_Date` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `added_to`
--

INSERT INTO `added_to` (`Person_ID`, `Waiting_List_ID`, `Temporary_Hold_Date`) VALUES
(1, 101, '2024-12-01'),
(2, 102, '2024-12-02'),
(3, 103, '2024-12-03'),
(6, 106, '2024-12-06'),
(7, 107, '2024-12-07'),
(8, 108, '2024-12-08'),
(9, 109, '2024-12-09'),
(10, 110, '2024-12-10');

-- --------------------------------------------------------

--
-- Table structure for table `dependent`
--

CREATE TABLE `dependent` (
  `Name` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Person_ID` int(11) NOT NULL,
  `Relationship_Type` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `dependent`
--

INSERT INTO `dependent` (`Name`, `Person_ID`, `Relationship_Type`) VALUES
('Ali', 1, 'Brother'),
('Fahad', 9, 'Father'),
('Lina', 7, 'Sister'),
('Mona', 8, 'Mother'),
('Omar', 3, 'Father'),
('Rami', 10, 'Son'),
('Sara', 2, 'Daughter'),
('Zain', 6, 'Brother');

-- --------------------------------------------------------

--
-- Table structure for table `passenger`
--

CREATE TABLE `passenger` (
  `Person_ID` int(11) NOT NULL,
  `Loyalty_Miles` float DEFAULT NULL,
  `Loyalty_Classs` float DEFAULT NULL,
  `Gender` varchar(6) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Nationality` char(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Date_Of_Birth` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `passenger`
--

INSERT INTO `passenger` (`Person_ID`, `Loyalty_Miles`, `Loyalty_Classs`, `Gender`, `Nationality`, `Date_Of_Birth`) VALUES
(1, 1200.5, 1, 'Male', 'Saudi', '1990-05-12'),
(2, 350.25, 2, 'Female', 'Saudi', '1995-08-25'),
(3, 5200.75, 3, 'Male', 'Egyptian', '1987-11-30'),
(4, 1500, 1, 'Female', 'Saudi', '1992-07-10'),
(5, 200.75, 2, 'Male', 'Jordanian', '1994-03-25'),
(6, 3200.5, 3, 'Female', 'Emirati', '1989-11-05'),
(7, 420.3, 1, 'Male', 'Bahraini', '1993-09-15'),
(8, 800.9, 2, 'Female', 'Kuwaiti', '1996-01-20'),
(9, 600.45, 3, 'Male', 'Omani', '1990-04-18'),
(12, 3000.5, 2, 'Female', 'Saudi', '1990-07-20'),
(13, 2200.75, 1, 'Male', 'Qatari', '1992-03-15'),
(14, 1500.25, 3, 'Female', 'Omani', '1994-11-25'),
(15, 1800.5, 2, 'Male', 'Bahraini', '1991-05-30'),
(16, 2700.9, 1, 'Female', 'Emirati', '1993-08-10'),
(235, NULL, NULL, 'Male', 'Pak', '2024-12-04'),
(342, NULL, NULL, 'Male', 'Pak', '2024-12-11'),
(12345, NULL, NULL, 'Male', 'Pak', '2024-12-15'),
(500003, NULL, NULL, 'Male', 'Saudi', '2024-12-01'),
(555554, NULL, NULL, 'Male', 'Saudi', '2024-12-03'),
(5000033, NULL, NULL, 'Male', 'Saudi', '2024-12-05');

-- --------------------------------------------------------

--
-- Table structure for table `passenger_users`
--

CREATE TABLE `passenger_users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Person_ID` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `passenger_users`
--

INSERT INTO `passenger_users` (`id`, `username`, `password`, `Person_ID`, `created_at`) VALUES
(4, 'pass1', '123', 1, '2023-12-01 07:00:00'),
(5, 'pass2', '123', 2, '2023-12-01 07:15:00'),
(6, 'pass3', '123', 3, '2023-12-01 07:30:00');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `Payment_ID` int(11) NOT NULL,
  `Reservation_ID` int(11) NOT NULL,
  `Payment_Date` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Payment_Type` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Status` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Amount` decimal(10,2) NOT NULL,
  `Card_Number` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Expiry_Month` int(2) NOT NULL,
  `Expiry_Year` int(4) NOT NULL,
  `CVV` varchar(4) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`Payment_ID`, `Reservation_ID`, `Payment_Date`, `Payment_Type`, `Status`, `Amount`, `Card_Number`, `Expiry_Month`, `Expiry_Year`, `CVV`) VALUES
(1, 201, '2024-12-01', 'Credit Card', 'Completed', 0.00, '', 0, 0, ''),
(2, 202, '2024-12-02', 'Credit Card', 'Failed', 0.00, '', 0, 0, ''),
(3, 203, '2024-12-03', 'Credit Card', 'Failed', 0.00, '', 0, 0, ''),
(6, 206, '2024-12-06', 'Credit Card', 'Completed', 0.00, '', 0, 0, ''),
(7, 207, '2024-12-07', 'Credit Card', 'Failed', 0.00, '', 0, 0, ''),
(8, 208, '2024-12-08', 'Credit Card', 'Failed', 0.00, '', 0, 0, ''),
(9, 209, '2024-12-09', 'Credit Card', 'Completed', 0.00, '', 0, 0, ''),
(10, 210, '2024-12-10', 'Credit Card', 'Failed', 0.00, '', 0, 0, ''),
(11, 228, '2024-12-15', 'Credit Card', 'Completed', 150.00, '4242424242424242424', 12, 2025, '123'),
(12, 229, '2024-12-15', 'Credit Card', 'Completed', 180.00, '424242424424224', 12, 2025, '123'),
(13, 230, '2024-12-15', 'Credit Card', 'Cancelled', 180.00, '42424242424242', 12, 2026, '123');

-- --------------------------------------------------------

--
-- Table structure for table `person`
--

CREATE TABLE `person` (
  `Person_ID` int(11) NOT NULL,
  `FName` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `MName` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `LName` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `person`
--

INSERT INTO `person` (`Person_ID`, `FName`, `MName`, `LName`) VALUES
(1, 'Ahmad', 'Ali', 'Al-Farsi'),
(2, 'Mohammad', 'Sami', 'Al-Saadi'),
(3, 'Omar', 'Hassan', 'Al-Mansoori'),
(4, 'Layla', 'Ahmed', 'Al-Sabah'),
(5, 'Tariq', 'Mohammad', 'Al-Jabri'),
(6, 'Fatima', 'Saif', 'Al-Maktoum'),
(7, 'Khalid', 'Abdulaziz', 'Al-Khalifa'),
(8, 'Noura', 'Fahad', 'Al-Mutairi'),
(9, 'Saleh', 'Hassan', 'Al-Zahrani'),
(12, 'Hana', 'Ali', 'Al-Fahad'),
(13, 'Salem', 'Mohammad', 'Al-Thani'),
(14, 'Nadia', 'Khalid', 'Al-Mazroui'),
(15, 'Omar', 'Fahad', 'Al-Khalifa'),
(16, 'Reem', 'Saif', 'Al-Nahyan'),
(235, 'Ali', NULL, 'Shah'),
(342, 'Ali', NULL, 'Shah'),
(12345, 'Ali', NULL, 'Shah'),
(500003, 'dddd', '', 'aaaaa'),
(555554, 'uuuu', '', 'llll'),
(5000033, 'dddd', '', 'aaaaa');

-- --------------------------------------------------------

--
-- Table structure for table `person_contact_info`
--

CREATE TABLE `person_contact_info` (
  `Phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Person_ID` int(11) NOT NULL,
  `Email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `person_contact_info`
--

INSERT INTO `person_contact_info` (`Phone`, `Person_ID`, `Email`) VALUES
('101', 1, 'pass1@example.com'),
('102', 2, 'pass2@example.com'),
('103', 3, 'pass3@example.com'),
('106', 6, NULL),
('107', 7, NULL),
('108', 8, NULL),
('109', 9, NULL),
('110', 10, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `reservation`
--

CREATE TABLE `reservation` (
  `Reservation_ID` int(11) NOT NULL,
  `Seat_Number` int(11) DEFAULT NULL,
  `Passenger_ID` int(11) NOT NULL,
  `Train_ID` int(11) NOT NULL,
  `From_Station` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `To_Station` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Coach_Class` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Payment_Status` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Reservation_Status` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Luggage_Details` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Person_ID` int(11) NOT NULL,
  `Name` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Price` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `reservation`
--

INSERT INTO `reservation` (`Reservation_ID`, `Seat_Number`, `Passenger_ID`, `Train_ID`, `From_Station`, `To_Station`, `Coach_Class`, `Payment_Status`, `Reservation_Status`, `Luggage_Details`, `Person_ID`, `Name`, `Price`) VALUES
(1, 0, 0, 14, '', '', '', 'Pending', '', NULL, 0, '', 120.00),
(201, 1, 1, 301, 'Riyadh', 'Jeddah', 'Economy Class', 'Paid', 'Confirmed', '1 Bag', 1, 'Ahmad Al-Farsi', 90.00),
(202, 2, 2, 302, 'Dammam', 'Mekkah', 'Business Class', 'Failed', 'Waiting', 'None', 2, 'Mohammad Sami', 180.00),
(203, 3, 3, 303, 'Medina', 'Makkah', 'Economy Class', 'Failed', 'Cancelled', '1 Bag', 3, 'Omar Hassan', 90.00),
(206, 6, 6, 306, 'Riyadh', 'Dammam', 'Business Class', 'Paid', 'Confirmed', '1 Bag', 6, 'Hana Al-Fahad', 180.00),
(207, 7, 7, 307, 'Jeddah', 'Makkah', 'Economy Class', 'Failed', 'Waiting', '2 Bags', 7, 'Salem Al-Thani', 90.00),
(208, 8, 8, 308, 'Medina', 'Jeddah', 'Economy Class', 'Failed', 'Cancelled', 'None', 8, 'Nadia Al-Mazroui', 90.00),
(209, 9, 9, 309, 'Hofuf', 'Riyadh', 'Economy Class', 'Paid', 'Confirmed', '1 Bag', 9, 'Omar Al-Khalifa', 90.00),
(210, 10, 10, 310, 'Jeddah', 'Medina', 'Business Class', 'Failed', 'Waiting', '1 Bag', 10, 'Reem Al-Nahyan', 180.00),
(225, 12, 5000033, 303, 'Test', 'Test to', 'Economy Class', 'Pending', 'Confirmed', NULL, 5000033, 'dddd aaaaa', NULL),
(228, 1, 12345, 15, 'Jeddah', 'Medina', 'Economy', 'Pending', 'Completed', '2 Bags', 12345, 'Ahmad Al-Farsi', 150.00),
(229, 1, 235, 315, 'Jeddah', 'Medina', 'Economy', '0', 'Completed', '3 Bags', 235, 'Ahmad Al-Farsi', 180.00),
(230, 2, 342, 315, 'Jeddah', 'Medina', 'Economy', 'Cancelled', 'Cancelled', '3 Bags', 342, 'Ahmad Al-Farsi', 180.00);

-- --------------------------------------------------------

--
-- Table structure for table `reserves`
--

CREATE TABLE `reserves` (
  `Person_ID` int(11) NOT NULL,
  `Date` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `reserves`
--

INSERT INTO `reserves` (`Person_ID`, `Date`) VALUES
(1, '2024-12-01'),
(2, '2024-12-02'),
(3, '2024-12-03');

-- --------------------------------------------------------

--
-- Table structure for table `staff_assignments`
--

CREATE TABLE `staff_assignments` (
  `Assignment_ID` int(11) NOT NULL,
  `Staff_ID` int(11) NOT NULL,
  `Train_ID` int(11) NOT NULL,
  `Assignment_Date` datetime NOT NULL,
  `Role` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staff_assignments`
--

INSERT INTO `staff_assignments` (`Assignment_ID`, `Staff_ID`, `Train_ID`, `Assignment_Date`, `Role`) VALUES
(1, 2, 302, '2024-12-16 00:00:00', 'Engineer');

-- --------------------------------------------------------

--
-- Table structure for table `staff_member`
--

CREATE TABLE `staff_member` (
  `Person_ID` int(11) NOT NULL,
  `Role` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `staff_member`
--

INSERT INTO `staff_member` (`Person_ID`, `Role`) VALUES
(1, 'Conductor'),
(2, 'Driver'),
(3, 'Ticket Seller'),
(6, 'Conductor'),
(7, 'Driver'),
(8, 'Ticket Seller'),
(9, 'Engineer'),
(10, 'Security'),
(11, 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `staff_users`
--

CREATE TABLE `staff_users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Person_ID` int(11) DEFAULT NULL,
  `role` enum('staff','admin') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'staff',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `staff_users`
--

INSERT INTO `staff_users` (`id`, `username`, `password`, `Person_ID`, `role`, `created_at`) VALUES
(1, 'admin', '12345678', 11, 'admin', '2024-12-15 08:24:29');

-- --------------------------------------------------------

--
-- Table structure for table `station`
--

CREATE TABLE `station` (
  `station_id` int(11) NOT NULL,
  `name` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `station`
--

INSERT INTO `station` (`station_id`, `name`, `city`) VALUES
(1, 'Riyadh Central', 'Riyadh'),
(2, 'Jeddah Central', 'Jeddah'),
(3, 'Dammam Central', 'Dammam'),
(4, 'Makkah Central', 'Makkah'),
(5, 'Medina Central', 'Medina'),
(6, 'Al-Qassim Central', 'Al-Qassim'),
(7, 'Hofuf Central', 'Hofuf'),
(8, 'Majmaah Central', 'Majmaah'),
(10, 'Hail Central', 'Hail'),
(11, 'Qurayyat Central', 'Qurayyat'),
(12, 'Jauf Central', 'Jauf');

-- --------------------------------------------------------

--
-- Table structure for table `stops_at`
--

CREATE TABLE `stops_at` (
  `Schedule_ID` int(11) NOT NULL,
  `Station_ID` int(11) NOT NULL,
  `Sequence_Num` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `stops_at`
--

INSERT INTO `stops_at` (`Schedule_ID`, `Station_ID`, `Sequence_Num`) VALUES
(1, 1, 1),
(1, 2, 2),
(2, 3, 1),
(4, 6, 1),
(4, 7, 2),
(5, 6, 2),
(5, 8, 1),
(6, 10, 1);

-- --------------------------------------------------------

--
-- Table structure for table `track`
--

CREATE TABLE `track` (
  `Track_ID` int(11) NOT NULL,
  `Origin_Station` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Dest_Station` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `track`
--

INSERT INTO `track` (`Track_ID`, `Origin_Station`, `Dest_Station`) VALUES
(1, 'Riyadh', 'Jeddah'),
(2, 'Dammam', 'Riyadh'),
(3, 'Medina', 'Jeddah'),
(4, 'Hail', 'Jauf'),
(5, 'Dammam', 'Hofuf'),
(6, 'Makkah', 'Jeddah'),
(7, 'Qurayyat', 'Jauf'),
(8, 'Riyadh', 'Hofuf'),
(9, 'Riyadh', 'Majmaah'),
(10, 'Qassim', 'Majmaah'),
(11, 'Qassim', 'Hail'),
(12, 'Hail', 'Jauf');

-- --------------------------------------------------------

--
-- Table structure for table `train`
--

CREATE TABLE `train` (
  `Train_ID` int(11) NOT NULL,
  `Arabic_Name` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `English_Name` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Origin_City` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Destination_City` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Economy_Seats` int(11) DEFAULT '70',
  `Business_Seats` int(11) DEFAULT '30',
  `Total_Seats` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `train`
--

INSERT INTO `train` (`Train_ID`, `Arabic_Name`, `English_Name`, `Origin_City`, `Destination_City`, `Economy_Seats`, `Business_Seats`, `Total_Seats`) VALUES
(301, 'القطار السريع', 'Fast Train', 'Riyadh', 'Jeddah', 70, 30, 100),
(302, 'القطار المحلي', 'Local Train', 'Dammam', 'Riyadh', 70, 30, 100),
(303, 'قطار عالي السرعة', 'High-speed Train', 'Medina', 'Jeddah', 70, 30, 100),
(311, 'قطار سريع', 'Fast Train', 'Dammam', 'Riyadh', 70, 30, 100),
(312, 'قطار محلي', 'Local Train', 'Dammam', 'Riyadh', 70, 30, 100),
(313, 'قطار عالي السرعة', 'High-speed Train', 'Medina', 'Jeddah', 70, 30, 100),
(314, 'قطار سريع', 'Fast Train', 'Jeddah', 'Medina', 70, 30, 100),
(315, 'قطار محلي', 'Local Train', 'Jeddah', 'Medina', 70, 30, 100);

-- --------------------------------------------------------

--
-- Table structure for table `train_schedule`
--

CREATE TABLE `train_schedule` (
  `Schedule_ID` int(11) NOT NULL,
  `Train_ID` int(11) NOT NULL,
  `Date` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Station_ID` int(11) NOT NULL,
  `Arrival_Time` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Departure_Time` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Sequence` int(11) NOT NULL,
  `Economy_Price` decimal(10,2) DEFAULT '90.00',
  `Business_Price` decimal(10,2) DEFAULT '180.00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `train_schedule`
--

INSERT INTO `train_schedule` (`Schedule_ID`, `Train_ID`, `Date`, `Station_ID`, `Arrival_Time`, `Departure_Time`, `Sequence`, `Economy_Price`, `Business_Price`) VALUES
(11, 311, '2024-12-11', 8, '18:30', '18:00', 1, 90.00, 180.00),
(12, 312, '2024-12-13', 9, '19:30', '19:00', 2, 90.00, 180.00),
(13, 313, '2024-12-13', 10, '20:30', '20:00', 3, 90.00, 180.00),
(14, 314, '2024-12-14', 11, '22:30', '22:00', 4, 90.00, 180.00),
(15, 315, '2024-12-15', 12, '22:30', '22:00', 5, 90.00, 180.00);

-- --------------------------------------------------------

--
-- Table structure for table `travleson`
--

CREATE TABLE `travleson` (
  `Train_ID` int(11) NOT NULL,
  `Track_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `travleson`
--

INSERT INTO `travleson` (`Train_ID`, `Track_ID`) VALUES
(301, 1),
(302, 2),
(303, 3),
(311, 20),
(312, 21),
(313, 22),
(314, 23),
(315, 24);

-- --------------------------------------------------------

--
-- Table structure for table `waiting_list`
--

CREATE TABLE `waiting_list` (
  `Waiting_List_ID` int(11) NOT NULL,
  `Train_ID` int(11) NOT NULL,
  `Passenger_ID` int(11) DEFAULT NULL,
  `Reservation_ID` int(11) DEFAULT NULL,
  `Payment_Made` varchar(3) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `From_Station` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `To_Station` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Coach_Class` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Person_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `waiting_list`
--

INSERT INTO `waiting_list` (`Waiting_List_ID`, `Train_ID`, `Passenger_ID`, `Reservation_ID`, `Payment_Made`, `From_Station`, `To_Station`, `Coach_Class`, `Person_ID`) VALUES
(1, 301, 1, 201, 'No', '', '', '', 0),
(2, 302, 2, 202, 'Yes', '', '', '', 0),
(3, 303, 3, 203, 'No', '', '', '', 0),
(11, 311, 11, 211, 'Yes', '', '', '', 0),
(12, 312, 12, 212, 'No', '', '', '', 0),
(13, 313, 13, 213, 'Yes', '', '', '', 0),
(14, 314, 14, 214, 'No', '', '', '', 0),
(15, 315, 15, 215, 'Yes', '', '', '', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `added_to`
--
ALTER TABLE `added_to`
  ADD PRIMARY KEY (`Person_ID`,`Waiting_List_ID`);

--
-- Indexes for table `dependent`
--
ALTER TABLE `dependent`
  ADD PRIMARY KEY (`Name`,`Person_ID`);

--
-- Indexes for table `passenger`
--
ALTER TABLE `passenger`
  ADD PRIMARY KEY (`Person_ID`);

--
-- Indexes for table `passenger_users`
--
ALTER TABLE `passenger_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD KEY `passenger_id` (`Person_ID`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`Payment_ID`),
  ADD UNIQUE KEY `Reservation_ID_UNIQUE` (`Reservation_ID`);

--
-- Indexes for table `person`
--
ALTER TABLE `person`
  ADD PRIMARY KEY (`Person_ID`);

--
-- Indexes for table `person_contact_info`
--
ALTER TABLE `person_contact_info`
  ADD PRIMARY KEY (`Phone`),
  ADD UNIQUE KEY `Person_ID_UNIQUE` (`Person_ID`);

--
-- Indexes for table `reservation`
--
ALTER TABLE `reservation`
  ADD PRIMARY KEY (`Reservation_ID`),
  ADD UNIQUE KEY `Passenger_ID_UNIQUE` (`Passenger_ID`),
  ADD UNIQUE KEY `Person_ID_UNIQUE` (`Person_ID`);

--
-- Indexes for table `reserves`
--
ALTER TABLE `reserves`
  ADD PRIMARY KEY (`Person_ID`);

--
-- Indexes for table `staff_assignments`
--
ALTER TABLE `staff_assignments`
  ADD PRIMARY KEY (`Assignment_ID`);

--
-- Indexes for table `staff_member`
--
ALTER TABLE `staff_member`
  ADD PRIMARY KEY (`Person_ID`);

--
-- Indexes for table `staff_users`
--
ALTER TABLE `staff_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD KEY `staff_id` (`Person_ID`);

--
-- Indexes for table `station`
--
ALTER TABLE `station`
  ADD PRIMARY KEY (`station_id`);

--
-- Indexes for table `stops_at`
--
ALTER TABLE `stops_at`
  ADD PRIMARY KEY (`Schedule_ID`,`Station_ID`);

--
-- Indexes for table `track`
--
ALTER TABLE `track`
  ADD PRIMARY KEY (`Track_ID`);

--
-- Indexes for table `train`
--
ALTER TABLE `train`
  ADD PRIMARY KEY (`Train_ID`);

--
-- Indexes for table `train_schedule`
--
ALTER TABLE `train_schedule`
  ADD PRIMARY KEY (`Schedule_ID`);

--
-- Indexes for table `travleson`
--
ALTER TABLE `travleson`
  ADD PRIMARY KEY (`Train_ID`,`Track_ID`);

--
-- Indexes for table `waiting_list`
--
ALTER TABLE `waiting_list`
  ADD PRIMARY KEY (`Waiting_List_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `passenger_users`
--
ALTER TABLE `passenger_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `Payment_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `reservation`
--
ALTER TABLE `reservation`
  MODIFY `Reservation_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=231;

--
-- AUTO_INCREMENT for table `staff_assignments`
--
ALTER TABLE `staff_assignments`
  MODIFY `Assignment_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `staff_users`
--
ALTER TABLE `staff_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `waiting_list`
--
ALTER TABLE `waiting_list`
  MODIFY `Waiting_List_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `passenger_users`
--
ALTER TABLE `passenger_users`
  ADD CONSTRAINT `passenger_users_ibfk_1` FOREIGN KEY (`Person_ID`) REFERENCES `passenger` (`Person_ID`);

--
-- Constraints for table `staff_users`
--
ALTER TABLE `staff_users`
  ADD CONSTRAINT `staff_users_ibfk_1` FOREIGN KEY (`Person_ID`) REFERENCES `staff_member` (`Person_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
