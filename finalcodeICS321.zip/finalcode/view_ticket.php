<?php
session_start();
include 'includes/db_connection.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Get the reservation ID from the query parameter
$reservationId = isset($_GET['reservation_id']) ? intval($_GET['reservation_id']) : 0;

// Fetch reservation and person details
$stmt = $conn->prepare("
    SELECT 
        r.From_Station, r.To_Station, r.Coach_Class, r.Price,
        ts.Departure_Time, ts.Arrival_Time, t.English_Name AS Train_Name, r.Seat_Number,
        p.FName, p.LName
    FROM reservation r
    JOIN train_schedule ts ON r.Train_ID = ts.Train_ID
    JOIN train t ON ts.Train_ID = t.Train_ID
    JOIN person p ON r.Person_ID = p.Person_ID
    WHERE r.Reservation_ID = ?
");
$stmt->bind_param("i", $reservationId);
$stmt->execute();
$stmt->bind_result($fromStation, $toStation, $coachClass, $price, $departureTime, $arrivalTime, $trainName, $seatNumber, $firstName, $lastName);
$stmt->fetch();
$stmt->close();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Train Ticket</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        h1, h2 {
            text-align: center;
            color: #333;
        }
        p {
            margin: 10px 0;
            color: #555;
        }
        .button {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s ease;
            text-align: center;
        }
        .button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Train Ticket</h1>
        <p><strong>Passenger Name:</strong> <?php echo htmlspecialchars($firstName . ' ' . $lastName); ?></p>
        <p><strong>Train Name:</strong> <?php echo htmlspecialchars($trainName); ?></p>
        <p><strong>From:</strong> <?php echo htmlspecialchars($fromStation); ?></p>
        <p><strong>To:</strong> <?php echo htmlspecialchars($toStation); ?></p>
        <p><strong>Departure Time:</strong> <?php echo htmlspecialchars($departureTime); ?></p>
        <p><strong>Arrival Time:</strong> <?php echo htmlspecialchars($arrivalTime); ?></p>
        <p><strong>Coach Class:</strong> <?php echo htmlspecialchars($coachClass); ?></p>
        <p><strong>Seat Number:</strong> <?php echo htmlspecialchars($seatNumber); ?></p>
        <p><strong>Price:</strong> <?php echo number_format($price, 2); ?> SAR</p>
    </div>
    <a href="search_trains.php" class="button">Back to Reservations</a>
</body>
</html> 