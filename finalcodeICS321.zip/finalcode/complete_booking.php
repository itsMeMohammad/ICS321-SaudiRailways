<?php
session_start();
include 'includes/db_connection.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Initialize variables
$passengerCount = isset($_GET['passenger_count']) ? intval($_GET['passenger_count']) : 1;
$selectedTrainId = isset($_GET['selected_train_id']) ? $_GET['selected_train_id'] : null;
$returnScheduleId = isset($_GET['return_schedule_id']) ? $_GET['return_schedule_id'] : null;

// Initialize error message
$errorMessage = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $passengers = $_POST['passengers'];
    $totalAmount = 0;

    // Calculate total amount based on class and luggage
    foreach ($passengers as $passenger) {
        // Check if Personal ID already exists
        $stmt = $conn->prepare("SELECT COUNT(*) FROM person WHERE Person_ID = ?");
        $stmt->bind_param("s", $passenger['personal_id']);
        $stmt->execute();
        $stmt->bind_result($count);
        $stmt->fetch();
        $stmt->close(); // Close the statement before proceeding

        if ($count > 0) {
            $errorMessage = "Personal ID " . htmlspecialchars($passenger['personal_id']) . " already exists. Please enter a unique ID.";
            break; // Exit the loop if a duplicate is found
        }

        $classPrice = ($passenger['class'] === 'Economy') ? 90 : 180; // Set price based on class
        $luggageCount = intval($passenger['luggage']); // Get luggage count
        $totalAmount += $classPrice + ($luggageCount * 30); // Add luggage cost

        // Insert into person table
        $stmt = $conn->prepare("INSERT INTO person (Person_ID, FName, LName) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $passenger['personal_id'], $passenger['first_name'], $passenger['last_name']);
        $stmt->execute();
        $stmt->close(); // Close the statement after execution

        // Prepare and bind for passenger
        $stmt = $conn->prepare("INSERT INTO passenger (Nationality, Person_ID, Gender, Date_Of_Birth) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $passenger['nationality'], $passenger['personal_id'], $passenger['gender'], $passenger['date_of_birth']);
        $stmt->execute();
        $stmt->close(); // Close the statement after execution
    }

    if (empty($errorMessage)) {
        // Store passenger data in session for payment page
        $_SESSION['passengers'] = $passengers;
        $_SESSION['total_amount'] = $totalAmount;
        $_SESSION['selected_train_id'] = $selectedTrainId;

        // Store the first passenger's Personal_ID in the session
        $_SESSION['person_id'] = $passengers[0]['personal_id'];

        // Redirect to payment page
        header("Location: payment.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Complete Booking</title>
    <link rel="stylesheet" href="styles.css"> <!-- Link to your CSS file -->
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 800px;
            margin: auto;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            color: #007bff;
        }
        .error-message {
            color: red;
            text-align: center;
            margin-bottom: 20px;
        }
        fieldset {
            border: 1px solid #ccc;
            border-radius: 5px;
            padding: 10px;
            margin-bottom: 20px;
        }
        legend {
            font-weight: bold;
            color: #007bff;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        input[type="text"],
        input[type="date"],
        select {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        button {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            width: 100%;
        }
        button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Complete Your Booking</h1>
        <?php if ($errorMessage): ?>
            <div class="error-message"><?php echo $errorMessage; ?></div>
        <?php endif; ?>
        <form method="POST" action="">
            <?php for ($i = 0; $i < $passengerCount; $i++): ?>
                <fieldset>
                    <legend>Passenger <?php echo $i + 1; ?></legend>
                    <label for="first_name_<?php echo $i; ?>">First Name</label>
                    <input type="text" name="passengers[<?php echo $i; ?>][first_name]" required>

                    <label for="last_name_<?php echo $i; ?>">Last Name</label>
                    <input type="text" name="passengers[<?php echo $i; ?>][last_name]" required>

                    <label for="nationality_<?php echo $i; ?>">Nationality</label>
                    <input type="text" name="passengers[<?php echo $i; ?>][nationality]" required>

                    <label for="personal_id_<?php echo $i; ?>">Personal ID</label>
                    <input type="text" name="passengers[<?php echo $i; ?>][personal_id]" required>

                    <label for="gender_<?php echo $i; ?>">Gender</label>
                    <select name="passengers[<?php echo $i; ?>][gender]" required>
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                    </select>

                    <label for="class_<?php echo $i; ?>">Class</label>
                    <select name="passengers[<?php echo $i; ?>][class]" required>
                        <option value="Economy">Economy</option>
                        <option value="Business">Business</option>
                    </select>

                    <label for="luggage_<?php echo $i; ?>">Additional Luggage (Number of Bags)</label>
                    <input type="number" name="passengers[<?php echo $i; ?>][luggage]" min="0" value="0" required>
                    
                    <label for="dob_<?php echo $i; ?>">Date of Birth</label>
                    <input type="date" name="passengers[<?php echo $i; ?>][date_of_birth]" required>
                </fieldset>
            <?php endfor; ?>
            <button type="submit">Continue</button>
        </form>
    </div>
</body>
</html>