<?php
session_start();
include 'includes/db_connection.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Access total amount and other details from session
$totalAmount = isset($_SESSION['total_amount']) ? $_SESSION['total_amount'] : 0;
$fromStation = isset($_SESSION['from_station']) ? $_SESSION['from_station'] : '';
$toStation = isset($_SESSION['to_station']) ? $_SESSION['to_station'] : '';
$userFullName = isset($_SESSION['full_name']) ? $_SESSION['full_name'] : '';

// Check if total amount is set
if ($totalAmount <= 0) {
    die("Error: Total amount is not set.");
}

// Initialize error message
$errorMessage = '';

// Initialize reservation status
$reservationStatus = 'Completed'; // Set a default value for reservation status

// Handle form submission for payment
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $cardNumber = $_POST['card_number'];
    $expireMonth = $_POST['expire_month'];
    $expireYear = $_POST['expire_year'];
    $cvv = $_POST['cvv'];

    // Initialize payment status
    $paymentStatus = 'Completed'; // Default to completed

    try {
        // Retrieve the correct Passenger_ID and Person_ID from the session
        $passengerId = $_SESSION['person_id']; // Assuming person_id is the correct Passenger_ID
        $personId = $_SESSION['passengers'][0]['personal_id']; // Use the Personal_ID of the first passenger

        // Set Luggage_Details
        $luggageDetails = isset($_SESSION['passengers'][0]['luggage']) ? $_SESSION['passengers'][0]['luggage'] . ' Bags' : 'No Luggage';

        // Insert a single reservation record
        $stmt = $conn->prepare("INSERT INTO reservation (Train_ID, Price, Payment_Status, Passenger_ID, Luggage_Details, From_Station, To_Station, Coach_Class, Reservation_Status, Name, Person_ID) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("idisssssssi", $_SESSION['selected_train_id'], $totalAmount, $paymentStatus, $passengerId, $luggageDetails, $fromStation, $toStation, $_SESSION['passengers'][0]['class'], $reservationStatus, $userFullName, $personId);
        $stmt->execute();
        $reservationId = $stmt->insert_id; // Get the auto-generated Reservation_ID
        $stmt->close();

        // Insert payment details into the database for each reservation
        $paymentDate = date('Y-m-d'); // Set payment date to current date
        $paymentType = 'Credit Card'; // Set payment type

        $stmt = $conn->prepare("INSERT INTO payment (Reservation_ID, Amount, Card_Number, Expiry_Month, Expiry_Year, CVV, Status, Payment_Date, Payment_Type) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("idssissss", $reservationId, $totalAmount, $cardNumber, $expireMonth, $expireYear, $cvv, $paymentStatus, $paymentDate, $paymentType);
        $stmt->execute();
        $stmt->close();

        // Find the next available seat number for the train
        $stmt = $conn->prepare("SELECT MAX(Seat_Number) AS LastSeat FROM reservation WHERE Train_ID = ?");
        $stmt->bind_param("i", $_SESSION['selected_train_id']);
        $stmt->execute();
        $stmt->bind_result($lastSeat);
        $stmt->fetch();
        $stmt->close();

        $nextSeat = $lastSeat + 1; // Assign the next seat number

        // Update the reservation with the seat number
        $stmt = $conn->prepare("UPDATE reservation SET Seat_Number = ? WHERE Reservation_ID = ?");
        $stmt->bind_param("ii", $nextSeat, $reservationId);
        $stmt->execute();
        $stmt->close();

        // Redirect to a success page
        $_SESSION['reservation_ids'] = [$reservationId]; // Store reservation IDs for the success page
        header("Location: success.php");
        exit();
    } catch (Exception $e) {
        $paymentStatus = 'Failed'; // Set payment status to failed if an error occurs
        $errorMessage = "Payment failed: " . $e->getMessage();

        // Update the reservation with the failed payment status
        $stmt = $conn->prepare("UPDATE reservation SET Payment_Status = ? WHERE Reservation_ID = ?");
        $stmt->bind_param("si", $paymentStatus, $reservationId);
        $stmt->execute();
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 800px;
            margin: auto;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            color: #007bff;
        }
        .error-message {
            color: red;
            text-align: center;
            margin-bottom: 20px;
        }
        .input-group {
            margin-bottom: 15px;
        }
        input[type="text"],
        input[type="number"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        button {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            width: 100%;
        }
        button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Payment</h1>
        <p>Total Amount: <?php echo $totalAmount; ?> Riyals</p>
        <?php if ($errorMessage): ?>
            <div class="error-message"><?php echo $errorMessage; ?></div>
        <?php endif; ?>
        <form method="POST" action="">
            <div class="input-group">
                <label for="card_number">CARD NUMBER</label>
                <input type="text" name="card_number" required>
            </div>
            <div class="input-group">
                <label for="expire_month">EXPIRE MONTH</label>
                <input type="number" name="expire_month" min="1" max="12" required>
            </div>
            <div class="input-group">
                <label for="expire_year">EXPIRE YEAR</label>
                <input type="number" name="expire_year" min="2023" required>
            </div>
            <div class="input-group">
                <label for="cvv">CVV</label>
                <input type="text" name="cvv" required>
            </div>
            <button type="submit">Pay <?php echo $totalAmount; ?> Riyals</button>
        </form>
    </div>
</body>
</html>
