<?php
session_start();
include 'includes/db_connection.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Retrieve reservation and passenger details from session
$reservationIds = $_SESSION['reservation_ids'];
$passengers = $_SESSION['passengers'];

// Fetch reservation details using Reservation_ID
$reservationId = $reservationIds[0]; // Assuming there's at least one reservation
$stmt = $conn->prepare("
    SELECT 
        r.From_Station, r.To_Station, r.Train_ID
    FROM reservation r
    WHERE r.Reservation_ID = ?
");
$stmt->bind_param("i", $reservationId);
$stmt->execute();
$stmt->bind_result($fromStation, $toStation, $trainId);
$stmt->fetch();
$stmt->close();

// Fetch train schedule details using Train_ID from reservation
$stmt = $conn->prepare("
    SELECT 
        ts.Departure_Time, ts.Arrival_Time, ts.Train_ID
    FROM train_schedule ts
    WHERE ts.Train_ID = ?
");
$stmt->bind_param("i", $trainId); // Assuming $trainId is the Schedule_ID
$stmt->execute();
$stmt->bind_result($departureTime, $arrivalTime, $actualTrainId);
$stmt->fetch();
$stmt->close();

// Fetch train name using actual Train_ID from train_schedule
$stmt = $conn->prepare("
    SELECT 
        t.English_Name AS Train_Name
    FROM train t
    WHERE t.Train_ID = ?
");
$stmt->bind_param("i", $actualTrainId);
$stmt->execute();
$stmt->bind_result($trainName);
$stmt->fetch();
$stmt->close();

$trainDetails = [
    'train_name' => $trainName,
    'from_station' => $fromStation,
    'to_station' => $toStation,
    'departure_time' => $departureTime,
    'arrival_time' => $arrivalTime
];

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking Success</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 800px;
            margin: auto;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            color: #007bff;
        }
        .ticket {
            border: 1px solid #ccc;
            border-radius: 5px;
            padding: 10px;
            margin-bottom: 20px;
        }
        .ticket p {
            margin: 5px 0;
        }
        .button {
            display: inline-block;
            padding: 10px 20px;
            margin-top: 20px;
            background-color: #007bff;
            color: white;
            text-align: center;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Booking Successful!</h1>
        <p>Your booking has been completed successfully. Here are your tickets:</p>
        
        <?php foreach ($passengers as $index => $passenger): ?>
            <?php
            // Fetch the seat number from the reservation table
            $stmt = $conn->prepare("SELECT Seat_Number FROM reservation WHERE Reservation_ID = ?");
            $stmt->bind_param("i", $reservationIds[$index]);
            $stmt->execute();
            $stmt->bind_result($seatNumber);
            $stmt->fetch();
            $stmt->close();
            ?>
            <div class="ticket">
                <h2>Train Ticket</h2>
                <p><strong>Passenger Name:</strong> <?php echo htmlspecialchars($passenger['first_name'] . ' ' . $passenger['last_name']); ?></p>
                <p><strong>Train Name:</strong> <?php echo htmlspecialchars($trainDetails['train_name']); ?></p>
                <p><strong>From:</strong> <?php echo htmlspecialchars($trainDetails['from_station']); ?></p>
                <p><strong>To:</strong> <?php echo htmlspecialchars($trainDetails['to_station']); ?></p>
                <p><strong>Departure Time:</strong> <?php echo htmlspecialchars($trainDetails['departure_time']); ?></p>
                <p><strong>Arrival Time:</strong> <?php echo htmlspecialchars($trainDetails['arrival_time']); ?></p>
                <p><strong>Coach Class:</strong> <?php echo htmlspecialchars($passenger['class']); ?></p>
                <p><strong>Luggage:</strong> <?php echo htmlspecialchars($passenger['luggage']); ?> Bags</p>
                <p><strong>Seat Number:</strong> <?php echo htmlspecialchars($seatNumber); ?></p>
            </div>
        <?php endforeach; ?>

        <!-- Add back to search button -->
        <a href="search_trains.php" class="button">Back to Search Trains</a>
    </div>
</body>
</html> 